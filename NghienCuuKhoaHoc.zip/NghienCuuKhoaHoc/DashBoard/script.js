// =========================
//   TASK LIST (Việc cần làm)
// =========================

/**
 * Cập nhật nội dung badge đếm số task đã hoàn thành.
 */
function updateTaskCounter() {
    var total = document.querySelectorAll('.todo-checkbox').length;
    var completed = document.querySelectorAll('.todo-checkbox:checked').length;
    var badge = document.getElementById('taskCounterBadge');

    if (badge) {
        badge.textContent = completed + '/' + total + ' hoàn thành';

        if (completed === total) {
            badge.className = 'px-2 py-0.5 rounded-full bg-secondary text-on-secondary font-label-sm text-label-sm font-semibold';
        } else {
            badge.className = 'px-2 py-0.5 rounded-full bg-secondary-fixed text-secondary font-label-sm text-label-sm font-semibold';
        }
    }
}

/**
 * Gắn sự kiện thay đổi trạng thái cho một checkbox task.
 * @param {HTMLInputElement} checkbox - Phần tử checkbox cần gắn sự kiện.
 * @param {HTMLElement} parentLabel - Phần tử label cha chứa checkbox.
 */
function bindTodoCheckbox(checkbox, parentLabel) {
    checkbox.addEventListener('change', function () {
        var textTitle = parentLabel.querySelector('.task-title');

        if (this.checked) {
            textTitle.classList.add('line-through', 'text-outline');
            textTitle.classList.remove('text-on-surface');
            parentLabel.classList.add('bg-surface-container-low/50');
            parentLabel.classList.remove('shadow-sm');
        } else {
            textTitle.classList.remove('line-through', 'text-outline');
            textTitle.classList.add('text-on-surface');
            parentLabel.classList.remove('bg-surface-container-low/50');
            parentLabel.classList.add('shadow-sm');
        }

        updateTaskCounter();
    });
}

// Gắn sự kiện cho tất cả checkbox hiện có khi tải trang
document.querySelectorAll('.todo-checkbox').forEach(function (box) {
    var parentLabel = box.closest('.todo-item');
    bindTodoCheckbox(box, parentLabel);
});


// =========================
//   CHARTS
// =========================

/**
 * Dữ liệu biểu đồ theo từng khoảng thời gian (7, 14, 30 ngày).
 */
var chartDatasets = {
    '7': {
        healthD: "M 50,60 L 160,55 L 270,52 L 380,58 L 490,48 L 600,42 L 710,38",
        healthArea: "M 50,60 L 160,55 L 270,52 L 380,58 L 490,48 L 600,42 L 710,38 L 710,220 L 50,220 Z",
        moistD: "M 50,95 L 160,102 L 270,92 L 380,95 L 490,88 L 600,84 L 710,82",
        moistArea: "M 50,95 L 160,102 L 270,92 L 380,95 L 490,88 L 600,84 L 710,82 L 710,220 L 50,220 Z",
        labels: ["17/01", "18/01", "19/01", "20/01", "21/01", "22/01", "Hôm nay"],
        ndvi: "92%",
        moist: "68%"
    },
    '14': {
        healthD: "M 50,75 L 105,72 L 160,78 L 215,65 L 270,60 L 325,55 L 380,52 L 435,58 L 490,48 L 545,44 L 600,40 L 655,42 L 710,38",
        healthArea: "M 50,75 L 105,72 L 160,78 L 215,65 L 270,60 L 325,55 L 380,52 L 435,58 L 490,48 L 545,44 L 600,40 L 655,42 L 710,38 L 710,220 L 50,220 Z",
        moistD: "M 50,110 L 105,105 L 160,115 L 215,108 L 270,122 L 325,98 L 380,102 L 435,92 L 490,95 L 545,88 L 600,84 L 655,80 L 710,82",
        moistArea: "M 50,110 L 105,105 L 160,115 L 215,108 L 270,122 L 325,98 L 380,102 L 435,92 L 490,95 L 545,88 L 600,84 L 655,80 L 710,82 L 710,220 L 50,220 Z",
        labels: ["09/01", "11/01", "13/01", "15/01", "18/01", "20/01", "Hôm nay"],
        ndvi: "92%",
        moist: "68%"
    },
    '30': {
        healthD: "M 50,95 L 160,88 L 270,78 L 380,68 L 490,55 L 600,45 L 710,38",
        healthArea: "M 50,95 L 160,88 L 270,78 L 380,68 L 490,55 L 600,45 L 710,38 L 710,220 L 50,220 Z",
        moistD: "M 50,130 L 160,120 L 270,110 L 380,100 L 490,92 L 600,85 L 710,82",
        moistArea: "M 50,130 L 160,120 L 270,110 L 380,100 L 490,92 L 600,85 L 710,82 L 710,220 L 50,220 Z",
        labels: ["24/12", "31/12", "07/01", "14/01", "18/01", "21/01", "Hôm nay"],
        ndvi: "92%",
        moist: "68%"
    }
};

// Xử lý sự kiện bấm nút chọn khoảng thời gian biểu đồ
document.querySelectorAll('.chart-range-btn').forEach(function (button) {
    button.addEventListener('click', function () {
        // Xoá trạng thái active của tất cả nút
        document.querySelectorAll('.chart-range-btn').forEach(function (btn) {
            btn.classList.remove(
                'active-chart-pill',
                'bg-surface-container-lowest',
                'text-primary',
                'shadow-sm',
                'font-semibold'
            );
            btn.classList.add('text-on-surface-variant');
        });

        // Thêm trạng thái active cho nút đang bấm
        this.classList.add(
            'active-chart-pill',
            'bg-surface-container-lowest',
            'text-primary',
            'shadow-sm',
            'font-semibold'
        );
        this.classList.remove('text-on-surface-variant');

        // Cập nhật đường biểu đồ theo dữ liệu mới
        var days = this.getAttribute('data-days');
        var data = chartDatasets[days];

        if (data) {
            document.getElementById('healthPath').setAttribute('d', data.healthD);
            document.getElementById('healthArea').setAttribute('d', data.healthArea);
            document.getElementById('moisturePath').setAttribute('d', data.moistD);
            document.getElementById('moistureArea').setAttribute('d', data.moistArea);
            document.getElementById('currentNdviDisplay').textContent = data.ndvi;
            document.getElementById('currentMoistureDisplay').textContent = data.moist;
        }
    });
});

// SVG Chart Node Tooltip - hiển thị tooltip khi hover vào điểm dữ liệu
var tooltip = document.getElementById('chartTooltip');
var chartContainer = document.getElementById('chartContainer');

document.querySelectorAll('#chartNodes circle').forEach(function (node) {
    node.addEventListener('mouseenter', function (e) {
        var day = this.getAttribute('data-day');
        var h = this.getAttribute('data-h');
        var m = this.getAttribute('data-m');

        document.getElementById('ttDate').textContent = day;
        document.getElementById('ttHealth').textContent = h;
        document.getElementById('ttMoist').textContent = m;

        var rect = this.getBoundingClientRect();
        var contRect = chartContainer.getBoundingClientRect();

        tooltip.style.left = (rect.left - contRect.left - 20) + 'px';
        tooltip.style.top = (rect.top - contRect.top - 55) + 'px';
        tooltip.classList.remove('hidden');
    });

    node.addEventListener('mouseleave', function () {
        tooltip.classList.add('hidden');
    });
});


// =========================
//   FIELD MAP (Ma trận lô ruộng)
// =========================

/**
 * Cập nhật thông tin lô được chọn trong thanh inspector phía dưới ma trận.
 * @param {string} sectorName - Tên lô (vd: 'A3').
 * @param {string} info - Thông tin mô tả tình trạng lô.
 * @param {string} status - Trạng thái: 'healthy' | 'attention' | 'warning'.
 */
function selectSectorDetail(sectorName, info, status) {
    var box = document.getElementById('sectorInfoBox');
    var title = document.getElementById('sectorSelectedTitle');
    title.innerHTML = 'Lô đang chọn: <strong>' + sectorName + '</strong> (' + info + ')';

    // Cập nhật màu nền theo trạng thái lô
    box.classList.remove('bg-surface-container-low', 'bg-amber-100', 'bg-red-100');

    if (status === 'attention') {
        box.classList.add('bg-amber-100');
    } else if (status === 'warning') {
        box.classList.add('bg-red-100');
    } else {
        box.classList.add('bg-surface-container-low');
    }
}

/**
 * Mở bảng chẩn đoán chuyên sâu cho một lô.
 * @param {string} sec - Tên lô cần kiểm tra.
 */
function inspectSector(sec) {
    alert('Đang mở bảng chẩn đoán chuyên sâu Lô ' + sec + ': Tải dữ liệu quang phổ NIR/Red-Edge và độ pH đất...');
}

/**
 * Kích hoạt drone bay quét bổ sung cho các lô bất thường.
 */
function quickDiagnose() {
    alert('Khởi động lệnh điều phối Drone bay quét bổ sung ảnh đa phổ tại các lô bất thường...');
}


// =========================
//   ALERTS (Cảnh báo)
// =========================

/**
 * Ẩn và xoá một card cảnh báo khỏi DOM.
 * Dùng class CSS .alert-dismissing để animate thay vì inline style.
 * @param {string} alertId - ID của card cần xoá.
 */
function dismissAlert(alertId) {
    var card = document.getElementById(alertId);
    if (card) {
        card.classList.add('alert-dismissing');
        setTimeout(function () {
            card.remove();
        }, 250);
    }
}


// =========================
//   IRRIGATION CONTROL
// =========================

/**
 * Mở van điện từ tưới cho một phân khu.
 * @param {string} sector - Tên phân khu (vd: 'B2').
 */
function quickIrrigate(sector) {
    alert('Lệnh đã gửi qua mạng LoRaWAN: Mở van điện từ phân khu ' + sector + ' tưới ngập 3cm.');
}

/**
 * Mở bảng điều khiển van cống Kênh N2.
 * @param {HTMLElement} btn - Nút bấm kích hoạt.
 */
function toggleSluice(btn) {
    alert('Đang mở bảng điều khiển đóng/mở van cống Kênh N2 theo thời gian thực.');
}


// =========================
//   SENSOR SYNC (Đồng bộ cảm biến)
// =========================

var sensorApiUrl = 'http://localhost:3000/api/sensor';
var sensorStatusUrl = sensorApiUrl + '/status';
var sensorConnectionIndicator = document.getElementById('sensorConnectionIndicator');
var sensorConnectionText = document.getElementById('sensorConnectionText');
var liveTemperature = document.getElementById('liveTemperature');

function setSensorConnectionStatus(connected, unavailable) {
    if (sensorConnectionText) {
        sensorConnectionText.textContent = unavailable
            ? 'Không kết nối được máy chủ cảm biến'
            : connected
                ? 'ESP32-S3 đang kết nối'
                : 'Đang chờ kết nối ESP32-S3';
    }

    if (sensorConnectionIndicator) {
        sensorConnectionIndicator.classList.toggle('bg-secondary', connected);
        sensorConnectionIndicator.classList.toggle('bg-outline', !connected && !unavailable);
        sensorConnectionIndicator.classList.toggle('bg-error', unavailable);
        sensorConnectionIndicator.classList.toggle('animate-pulse', connected);
    }

    if (!connected && liveTemperature) {
        liveTemperature.textContent = '--';
    }
}

async function refreshSensorData() {
    try {
        var statusResponse = await fetch(sensorStatusUrl, { cache: 'no-store' });
        if (!statusResponse.ok) {
            throw new Error('Sensor status request failed with HTTP ' + statusResponse.status);
        }

        var status = await statusResponse.json();
        setSensorConnectionStatus(status.connected === true, false);
        if (status.connected !== true) {
            return;
        }

        var sensorResponse = await fetch(sensorApiUrl, { cache: 'no-store' });
        if (!sensorResponse.ok) {
            throw new Error('Sensor data request failed with HTTP ' + sensorResponse.status);
        }

        var sensorData = await sensorResponse.json();
        if (liveTemperature && Number.isFinite(sensorData.temperature)) {
            liveTemperature.textContent = sensorData.temperature.toFixed(1);
        } else if (liveTemperature) {
            liveTemperature.textContent = '--';
        }
    } catch (error) {
        console.error('Unable to refresh ESP32 sensor data:', error);
        setSensorConnectionStatus(false, true);
    }
}

var refreshTelemetryButton = document.getElementById('btnRefreshTelemetry');
if (refreshTelemetryButton) {
    refreshTelemetryButton.addEventListener('click', async function () {
        var icon = this.querySelector('.material-symbols-outlined');
        if (icon) icon.classList.add('animate-spin');
        await refreshSensorData();
        if (icon) icon.classList.remove('animate-spin');
    });
}

refreshSensorData();
setInterval(refreshSensorData, 1000);


// =========================
//   ADD NEW TASK
// =========================

// Xử lý nút "Thêm công việc mới"
document.getElementById('btnAddNewTask').addEventListener('click', function () {
    var taskName = prompt('Nhập tên công việc canh tác mới:');

    if (taskName && taskName.trim() !== '') {
        var container = document.getElementById('todoContainer');
        var newLabel = document.createElement('label');

        newLabel.className = 'todo-item flex items-start gap-space-sm p-3 rounded-xl bg-surface-container-lowest hover:bg-surface-container-low cursor-pointer transition-all duration-150 shadow-sm';
        newLabel.innerHTML =
            '<input type="checkbox" class="todo-checkbox mt-0.5 w-5 h-5 rounded text-primary focus:ring-primary accent-primary cursor-pointer shrink-0">' +
            '<div class="flex-1 min-w-0">' +
                '<div class="task-title font-label-lg text-label-lg text-on-surface">' + taskName + '</div>' +
                '<div class="flex items-center justify-between font-body-sm text-body-sm mt-1">' +
                    '<span class="text-on-surface-variant flex items-center gap-1">' +
                        '<span class="material-symbols-outlined text-[14px]">schedule</span> Hôm nay' +
                    '</span>' +
                    '<span class="text-secondary font-label-sm text-label-sm">Thủ công</span>' +
                '</div>' +
            '</div>';

        container.appendChild(newLabel);

        // Gắn sự kiện cho checkbox của task mới
        var newCheckbox = newLabel.querySelector('.todo-checkbox');
        bindTodoCheckbox(newCheckbox, newLabel);

        updateTaskCounter();
    }
});
