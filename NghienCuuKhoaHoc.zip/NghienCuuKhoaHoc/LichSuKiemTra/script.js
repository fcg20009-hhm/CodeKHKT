// ============================================================
//  LỊCH SỬ KIỂM TRA — script.js
//  AgriAI RiceSmart
// ============================================================

// ---- Data -------------------------------------------------------

const FIELD_COLORS = {
  A: '#16a34a',
  B: '#2563eb',
  C: '#d97706'
};

const INSPECTIONS = [
  {
    id: 1,
    date: '05/02/2025', day: 'Thứ Tư', ago: '3 ngày trước',
    field: 'A', fieldName: 'Ruộng A', variety: 'OM5451 - Đông Xuân 2025',
    inspector: 'KS. Nguyễn Văn Nông', method: 'ai', methodLabel: 'Drone + AI',
    status: 'warning', statusLabel: 'Cảnh báo',
    score: 74, growthStage: 'Đẻ nhánh rộ (N38)',
    area: '2.5 ha', duration: '45 phút',
    findings: [
      { sev: 'med', icon: 'pest_control', text: 'Rầy nâu – mật độ trung bình', sub: 'Phát hiện ~250 con/m², vượt ngưỡng kinh tế 150 con/m²' },
      { sev: 'low', icon: 'water_drop', text: 'Độ ẩm đất tầng mặt thấp', sub: 'AWD: -18 cm, cần bơm nước bổ sung trong 24h' },
      { sev: 'low', icon: 'eco', text: 'Lá vàng nhẹ cục bộ ô Đông Bắc', sub: 'Nghi thiếu đạm, đề nghị bổ sung urê 2 kg/công' }
    ],
    recommendations: [
      'Phun Actara 25WG (thiamethoxam) 0.3g/lít nước, phun chiều mát.',
      'Bơm nước vào ruộng đến mức 3–5 cm, giữ tối thiểu 3 ngày.',
      'Bón bổ sung 2 kg urê/công cho ô Đông Bắc.'
    ]
  },
  {
    id: 2,
    date: '03/02/2025', day: 'Thứ Hai', ago: '5 ngày trước',
    field: 'B', fieldName: 'Ruộng B', variety: 'ST25 - Đông Xuân 2025',
    inspector: 'KTV. Trần Thị Mai', method: 'manual', methodLabel: 'Thăm đồng',
    status: 'healthy', statusLabel: 'Khỏe mạnh',
    score: 92, growthStage: 'Đẻ nhánh tối đa (N40)',
    area: '1.8 ha', duration: '30 phút',
    findings: [
      { sev: 'low', icon: 'check_circle', text: 'Cây lúa sinh trưởng tốt, đồng đều', sub: 'Số dảnh/cây đạt 22–25, đúng tiêu chuẩn' },
      { sev: 'low', icon: 'water_drop', text: 'Mực nước AWD ổn định', sub: '-8 cm, trong ngưỡng an toàn' }
    ],
    recommendations: [
      'Tiếp tục duy trì kỹ thuật AWD theo lịch.',
      'Kiểm tra lại sau 5 ngày để chuẩn bị giai đoạn làm đòng.'
    ]
  },
  {
    id: 3,
    date: '01/02/2025', day: 'Thứ Bảy', ago: '7 ngày trước',
    field: 'C', fieldName: 'Ruộng C', variety: 'Đài Thơm 8 - Đông Xuân 2025',
    inspector: 'KS. Nguyễn Văn Nông', method: 'sensor', methodLabel: 'Cảm biến IoT',
    status: 'danger', statusLabel: 'Nguy hiểm',
    score: 51, growthStage: 'Đẻ nhánh sớm (N32)',
    area: '3.2 ha', duration: '60 phút',
    findings: [
      { sev: 'high', icon: 'coronavirus', text: 'Đạo ôn lá – nhiễm nặng diện rộng', sub: 'Tỷ lệ lá nhiễm: 35–40%, cấp hại 5–7, vượt ngưỡng' },
      { sev: 'high', icon: 'pest_control', text: 'Sâu cuốn lá nhỏ gây hại', sub: 'Mật độ ~15 con/m², lá bị cuốn 20%' },
      { sev: 'med', icon: 'water_drop', text: 'Thiếu nước nghiêm trọng', sub: 'AWD: -32 cm, lúa bắt đầu héo nhẹ' }
    ],
    recommendations: [
      'Phun ngay Beam 75WP (tricyclazole) 20g/16 lít nước trong vòng 6 giờ.',
      'Phun Dupont Prevathon 5SC (chlorantraniliprole) trừ sâu cuốn lá.',
      'Bơm nước khẩn cấp, đảm bảo mực nước 5–7 cm trong 48h.',
      'Báo cáo Chi cục BVTV để hỗ trợ kỹ thuật tại chỗ.'
    ]
  },
  {
    id: 4,
    date: '28/01/2025', day: 'Thứ Ba', ago: '11 ngày trước',
    field: 'A', fieldName: 'Ruộng A', variety: 'OM5451 - Đông Xuân 2025',
    inspector: 'KTV. Lê Văn Đức', method: 'ai', methodLabel: 'Drone + AI',
    status: 'treated', statusLabel: 'Đã xử lý',
    score: 68, growthStage: 'Đẻ nhánh tích cực (N33)',
    area: '2.5 ha', duration: '50 phút',
    findings: [
      { sev: 'med', icon: 'pest_control', text: 'Rầy nâu – phát hiện sớm', sub: 'Mật độ ~120 con/m², gần ngưỡng kinh tế' },
      { sev: 'low', icon: 'eco', text: 'Bệnh đốm nâu xuất hiện rải rác', sub: 'Cấp hại 1–3, chưa ảnh hưởng năng suất' }
    ],
    recommendations: [
      'Theo dõi rầy nâu mỗi 3 ngày/lần.',
      'Tăng cường bón kali để tăng sức đề kháng cây lúa.'
    ]
  },
  {
    id: 5,
    date: '24/01/2025', day: 'Thứ Sáu', ago: '15 ngày trước',
    field: 'B', fieldName: 'Ruộng B', variety: 'ST25 - Đông Xuân 2025',
    inspector: 'KS. Nguyễn Văn Nông', method: 'manual', methodLabel: 'Thăm đồng',
    status: 'healthy', statusLabel: 'Khỏe mạnh',
    score: 88, growthStage: 'Đẻ nhánh tích cực (N29)',
    area: '1.8 ha', duration: '25 phút',
    findings: [
      { sev: 'low', icon: 'check_circle', text: 'Sinh trưởng đồng đều, không phát hiện sâu bệnh', sub: '' },
      { sev: 'low', icon: 'water_drop', text: 'AWD vận hành đúng kỹ thuật', sub: 'Mực nước -10 cm, bình thường' }
    ],
    recommendations: [
      'Duy trì lịch bón phân đợt 2 theo kế hoạch.',
      'Kiểm tra lại trước khi làm đòng.'
    ]
  },
  {
    id: 6,
    date: '18/01/2025', day: 'Thứ Bảy', ago: '21 ngày trước',
    field: 'C', fieldName: 'Ruộng C', variety: 'Đài Thơm 8 - Đông Xuân 2025',
    inspector: 'KTV. Trần Thị Mai', method: 'ai', methodLabel: 'Drone + AI',
    status: 'treated', statusLabel: 'Đã xử lý',
    score: 62, growthStage: 'Đẻ nhánh sớm (N22)',
    area: '3.2 ha', duration: '55 phút',
    findings: [
      { sev: 'med', icon: 'coronavirus', text: 'Đạo ôn lá – giai đoạn khởi phát', sub: 'Tỷ lệ lá nhiễm: 8%, cấp hại 1–3' },
      { sev: 'low', icon: 'pest_control', text: 'Sâu cuốn lá nhỏ mật độ thấp', sub: 'Dưới ngưỡng phòng trị' }
    ],
    recommendations: [
      'Phun phòng Filia 525SE (propiconazole + tricyclazole) phòng đạo ôn.',
      'Theo dõi thêm 5 ngày trước khi quyết định phun trừ sâu.'
    ]
  }
];

// ---- State ------------------------------------------------------
let currentFilter = 'all'; // status filter
let currentField = 'all';
let currentMethod = 'all';
let currentView = 'table';
let currentPage = 1;
const ROWS_PER_PAGE = 5;
let activeRecord = null;

// ---- Helpers ----------------------------------------------------
function getStatusClass(s) {
  return { healthy: 's-healthy', warning: 's-warning', danger: 's-danger', treated: 's-treated' }[s] || 's-healthy';
}
function getMethodClass(m) {
  return { ai: 'method-ai', manual: 'method-manual', sensor: 'method-sensor', drone: 'method-drone' }[m] || 'method-manual';
}
function getScoreColor(score) {
  if (score >= 85) return '#16a34a';
  if (score >= 65) return '#ca8a04';
  return '#dc2626';
}
function getTlNodeClass(status) {
  return status === 'danger' ? 'tl-node tl-danger' : status === 'warning' ? 'tl-node tl-warn' : 'tl-node';
}

// ---- Filter Logic -----------------------------------------------
function getFiltered() {
  return INSPECTIONS.filter(r => {
    const matchStatus = currentFilter === 'all' || r.status === currentFilter;
    const matchField  = currentField  === 'all' || r.field  === currentField;
    const matchMethod = currentMethod === 'all' || r.method === currentMethod;
    return matchStatus && matchField && matchMethod;
  });
}

// ---- Table Render -----------------------------------------------
function renderTable() {
  const data = getFiltered();
  const totalPages = Math.max(1, Math.ceil(data.length / ROWS_PER_PAGE));
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * ROWS_PER_PAGE;
  const page = data.slice(start, start + ROWS_PER_PAGE);

  const tbody = document.getElementById('logTbody');
  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><span class="material-symbols-outlined empty-icon">search_off</span><div class="empty-title">Không tìm thấy kết quả</div><div class="empty-sub">Thử thay đổi bộ lọc để hiển thị dữ liệu.</div></div></td></tr>`;
  } else {
    tbody.innerHTML = page.map(r => `
      <tr onclick="openModal(${r.id})">
        <td class="td-date">
          <div class="date-primary">${r.date}</div>
          <div class="date-day">${r.day}</div>
          <div class="date-ago">${r.ago}</div>
        </td>
        <td>
          <div class="field-badge">
            <span class="field-dot" style="background:${FIELD_COLORS[r.field]}"></span>
            <div>
              <div class="field-name">${r.fieldName}</div>
              <div class="field-variety">${r.variety}</div>
            </div>
          </div>
        </td>
        <td>
          <div class="insp-wrap">
            <div class="insp-avatar"><span class="material-symbols-outlined">person</span></div>
            <span class="insp-name">${r.inspector}</span>
          </div>
        </td>
        <td>
          <span class="method-badge ${getMethodClass(r.method)}">
            <span class="material-symbols-outlined" style="font-size:13px">${r.method === 'ai' ? 'smart_toy' : r.method === 'manual' ? 'person_search' : r.method === 'sensor' ? 'sensors' : 'flight'}</span>
            ${r.methodLabel}
          </span>
        </td>
        <td>
          <span class="status-pill ${getStatusClass(r.status)}">
            <span class="dot"></span>${r.statusLabel}
          </span>
        </td>
        <td>
          <div class="score-cell">
            <div class="score-bar-bg"><div class="score-bar-fill" style="width:${r.score}%;background:${getScoreColor(r.score)}"></div></div>
            <span class="score-val" style="color:${getScoreColor(r.score)}">${r.score}</span>
          </div>
        </td>
        <td class="td-actions">
          <button class="row-action-btn" onclick="event.stopPropagation();openModal(${r.id})" title="Xem chi tiết">
            <span class="material-symbols-outlined">open_in_new</span>
          </button>
          <button class="row-action-btn" onclick="event.stopPropagation();showToast('Đã sao chép ID kiểm tra #${r.id}')" title="Sao chép">
            <span class="material-symbols-outlined">content_copy</span>
          </button>
        </td>
      </tr>
    `).join('');
  }

  // Pagination
  document.getElementById('recordCount').textContent = `${data.length} bản ghi`;
  document.getElementById('paginationInfo').textContent = `Hiển thị ${Math.min(start+1, data.length)}–${Math.min(start + ROWS_PER_PAGE, data.length)} / ${data.length} bản ghi`;
  renderPagination(totalPages);
}

function renderPagination(totalPages) {
  const wrap = document.getElementById('paginationBtns');
  let html = `<button class="page-btn" onclick="goPage(${currentPage-1})" ${currentPage===1?'disabled style="opacity:.4;cursor:not-allowed"':''}><span class="material-symbols-outlined">chevron_left</span></button>`;
  for (let i = 1; i <= totalPages; i++) {
    html += `<button class="page-btn ${i===currentPage?'active':''}" onclick="goPage(${i})">${i}</button>`;
  }
  html += `<button class="page-btn" onclick="goPage(${currentPage+1})" ${currentPage===totalPages?'disabled style="opacity:.4;cursor:not-allowed"':''}><span class="material-symbols-outlined">chevron_right</span></button>`;
  wrap.innerHTML = html;
}

function goPage(p) {
  const data = getFiltered();
  const total = Math.max(1, Math.ceil(data.length / ROWS_PER_PAGE));
  if (p < 1 || p > total) return;
  currentPage = p;
  renderTable();
}

// ---- Timeline Render --------------------------------------------
function renderTimeline() {
  const data = getFiltered();
  const wrap = document.getElementById('timelineWrap');
  if (!data.length) {
    wrap.innerHTML = `<div class="empty-state"><span class="material-symbols-outlined empty-icon">timeline</span><div class="empty-title">Không có dữ liệu</div><div class="empty-sub">Thay đổi bộ lọc để xem dòng thời gian.</div></div>`;
    return;
  }
  wrap.innerHTML = `<div class="timeline-list">${data.map(r => `
    <div class="timeline-entry">
      <div class="tl-date-col">
        <div class="tl-date-main">${r.date}</div>
        <div class="tl-date-sub">${r.day}</div>
      </div>
      <div class="tl-connector">
        <div class="${getTlNodeClass(r.status)}"></div>
        <div class="tl-line"></div>
      </div>
      <div class="tl-card" onclick="openModal(${r.id})">
        <div class="tl-card-top">
          <div>
            <div class="tl-field">
              <span style="display:inline-block;width:8px;height:8px;border-radius:99px;background:${FIELD_COLORS[r.field]};margin-right:6px;vertical-align:middle"></span>
              ${r.fieldName} — ${r.variety}
            </div>
            <div class="tl-meta">
              <span class="method-badge ${getMethodClass(r.method)}">
                <span class="material-symbols-outlined" style="font-size:13px">${r.method === 'ai' ? 'smart_toy' : r.method === 'manual' ? 'person_search' : r.method === 'sensor' ? 'sensors' : 'flight'}</span>
                ${r.methodLabel}
              </span>
              <span class="method-badge" style="background:#f1f5f9;color:#475569">
                <span class="material-symbols-outlined" style="font-size:13px">person</span>
                ${r.inspector}
              </span>
            </div>
          </div>
          <span class="status-pill ${getStatusClass(r.status)}"><span class="dot"></span>${r.statusLabel}</span>
        </div>
        <div class="tl-findings">${r.findings.map(f => `• ${f.text}${f.sub ? ' – ' + f.sub : ''}`).join('<br>')}</div>
      </div>
    </div>
  `).join('')}</div>`;
}

// ---- Stat Cards -------------------------------------------------
function renderStats() {
  const total = INSPECTIONS.length;
  const healthy  = INSPECTIONS.filter(r => r.status === 'healthy').length;
  const warning  = INSPECTIONS.filter(r => r.status === 'warning').length;
  const danger   = INSPECTIONS.filter(r => r.status === 'danger').length;
  const treated  = INSPECTIONS.filter(r => r.status === 'treated').length;
  const avgScore = Math.round(INSPECTIONS.reduce((s, r) => s + r.score, 0) / total);

  document.getElementById('statTotal').textContent = total;
  document.getElementById('statHealthy').textContent = healthy;
  document.getElementById('statDanger').textContent = danger + warning;
  document.getElementById('statAvgScore').textContent = avgScore;

  // Donut chart (SVG)
  renderDonut([
    { label: 'Khỏe mạnh', count: healthy,  color: '#16a34a' },
    { label: 'Cảnh báo',  count: warning,  color: '#ca8a04' },
    { label: 'Nguy hiểm', count: danger,   color: '#dc2626' },
    { label: 'Đã xử lý',  count: treated,  color: '#2563eb' }
  ], total);

  // Bar chart by field
  renderBarChart([
    { label: 'Ruộng A', count: INSPECTIONS.filter(r => r.field === 'A').length, color: '#16a34a' },
    { label: 'Ruộng B', count: INSPECTIONS.filter(r => r.field === 'B').length, color: '#2563eb' },
    { label: 'Ruộng C', count: INSPECTIONS.filter(r => r.field === 'C').length, color: '#d97706' }
  ]);

  // Monthly trend
  renderTrend();
}

function renderDonut(slices, total) {
  const r = 40, cx = 56, cy = 56, stroke = 18;
  const circ = 2 * Math.PI * r;
  let offset = 0;
  const paths = slices.map(s => {
    const frac = s.count / total;
    const dash = frac * circ;
    const svg = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${s.color}" stroke-width="${stroke}" stroke-dasharray="${dash} ${circ - dash}" stroke-dashoffset="${-offset}" transform="rotate(-90 ${cx} ${cy})" stroke-linecap="butt"/>`;
    offset += dash;
    return svg;
  }).join('');
  const legend = slices.map(s => `
    <div class="legend-row">
      <span class="legend-dot" style="background:${s.color}"></span>
      <span>${s.label}</span>
      <span class="legend-pct">${s.count} (${Math.round(s.count/total*100)}%)</span>
    </div>
  `).join('');
  document.getElementById('donutChart').innerHTML = `
    <div class="donut-wrap">
      <svg class="donut-svg" width="112" height="112" viewBox="0 0 112 112">
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#e5eeff" stroke-width="${stroke}"/>
        ${paths}
        <text x="${cx}" y="${cy}" text-anchor="middle" dominant-baseline="central" font-size="13" font-weight="700" fill="#00450d">${total}</text>
      </svg>
      <div class="donut-legend">${legend}</div>
    </div>`;
}

function renderBarChart(items) {
  const max = Math.max(...items.map(i => i.count));
  document.getElementById('barChart').innerHTML = `<div class="bar-chart">${items.map(i => `
    <div class="bar-row">
      <span class="bar-label">${i.label}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${(i.count/max*100).toFixed(1)}%;background:${i.color}"></div></div>
      <span class="bar-count">${i.count}</span>
    </div>
  `).join('')}</div>`;
}

function renderTrend() {
  // Simulated monthly data
  const months = ['T10', 'T11', 'T12', 'T1', 'T2'];
  const counts  = [2, 3, 2, 4, 3];
  const maxC = Math.max(...counts);
  const W = 220, H = 70, pad = 8;
  const xs = months.map((_, i) => pad + i * ((W - pad*2) / (months.length - 1)));
  const ys = counts.map(c => H - pad - (c / maxC) * (H - pad*2));
  const pts = xs.map((x, i) => `${x},${ys[i]}`).join(' ');
  const area = `${xs[0]},${H} ` + pts + ` ${xs[xs.length-1]},${H}`;

  const svg = `
    <svg viewBox="0 0 ${W} ${H}" class="trend-svg" preserveAspectRatio="none">
      <defs>
        <linearGradient id="tg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#00450d" stop-opacity=".18"/>
          <stop offset="100%" stop-color="#00450d" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <polygon points="${area}" fill="url(#tg)"/>
      <polyline points="${pts}" fill="none" stroke="#00450d" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
      ${xs.map((x, i) => `<circle cx="${x}" cy="${ys[i]}" r="3.5" fill="#00450d"/>`).join('')}
      ${months.map((m, i) => `<text x="${xs[i]}" y="${H-1}" text-anchor="middle" font-size="9" fill="#717a6d">${m}</text>`).join('')}
    </svg>
  `;
  document.getElementById('trendChart').innerHTML = `<div class="trend-wrap">${svg}</div>`;
}

// ---- Modal ------------------------------------------------------
function openModal(id) {
  activeRecord = INSPECTIONS.find(r => r.id === id);
  if (!activeRecord) return;
  const r = activeRecord;

  document.getElementById('modalTag').textContent = `Báo cáo kiểm tra #INS-${String(r.id).padStart(4,'0')} • ${r.date}`;
  document.getElementById('modalTitle').textContent = `${r.fieldName} — ${r.variety}`;

  document.getElementById('modalDetails').innerHTML = `
    <div class="detail-item"><span class="detail-key">Ruộng</span><span class="detail-val" style="display:flex;align-items:center;gap:6px"><span style="width:10px;height:10px;border-radius:99px;background:${FIELD_COLORS[r.field]};display:inline-block"></span>${r.fieldName}</span></div>
    <div class="detail-item"><span class="detail-key">Giống lúa / Vụ</span><span class="detail-val">${r.variety}</span></div>
    <div class="detail-item"><span class="detail-key">Ngày kiểm tra</span><span class="detail-val">${r.date} (${r.day})</span></div>
    <div class="detail-item"><span class="detail-key">Người kiểm tra</span><span class="detail-val">${r.inspector}</span></div>
    <div class="detail-item"><span class="detail-key">Phương pháp</span><span class="detail-val"><span class="method-badge ${getMethodClass(r.method)}">${r.methodLabel}</span></span></div>
    <div class="detail-item"><span class="detail-key">Giai đoạn sinh trưởng</span><span class="detail-val">${r.growthStage}</span></div>
    <div class="detail-item"><span class="detail-key">Diện tích kiểm tra</span><span class="detail-val">${r.area}</span></div>
    <div class="detail-item"><span class="detail-key">Thời gian thực hiện</span><span class="detail-val">${r.duration}</span></div>
    <div class="detail-item"><span class="detail-key">Trạng thái</span><span class="detail-val"><span class="status-pill ${getStatusClass(r.status)}"><span class="dot"></span>${r.statusLabel}</span></span></div>
    <div class="detail-item"><span class="detail-key">Điểm sức khỏe cây</span><span class="detail-val" style="color:${getScoreColor(r.score)};font-weight:700;font-size:18px">${r.score}/100</span></div>
  `;

  document.getElementById('modalFindings').innerHTML = r.findings.map(f => `
    <div class="finding-item sev-${f.sev}">
      <div class="finding-icon"><span class="material-symbols-outlined">${f.icon}</span></div>
      <div><div class="finding-text">${f.text}</div>${f.sub ? `<div class="finding-sub">${f.sub}</div>` : ''}</div>
    </div>
  `).join('');

  document.getElementById('modalRecs').innerHTML = r.recommendations.map((rec, i) => `
    <div class="rec-item"><span class="rec-num">${i+1}</span><span>${rec}</span></div>
  `).join('');

  document.getElementById('modalBackdrop').classList.add('open');
}

function closeModal() {
  document.getElementById('modalBackdrop').classList.remove('open');
}

// ---- Toast ------------------------------------------------------
let toastTimer;
function showToast(msg) {
  const el = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

// ---- Filter Events ----------------------------------------------
function initFilters() {
  // Status chips
  document.querySelectorAll('.chip[data-status]').forEach(c => {
    c.addEventListener('click', () => {
      document.querySelectorAll('.chip[data-status]').forEach(x => x.classList.remove('active'));
      c.classList.add('active');
      currentFilter = c.dataset.status;
      currentPage = 1;
      refresh();
    });
  });

  // Field select
  document.getElementById('fieldFilter').addEventListener('change', e => {
    currentField = e.target.value;
    currentPage = 1;
    refresh();
  });

  // Method select
  document.getElementById('methodFilter').addEventListener('change', e => {
    currentMethod = e.target.value;
    currentPage = 1;
    refresh();
  });

  // Header field selector
  document.getElementById('fieldSelect').addEventListener('change', e => {
    const map = { 'all': 'all', 'A': 'A', 'B': 'B', 'C': 'C' };
    currentField = map[e.target.value] || 'all';
    currentPage = 1;
    refresh();
  });
}

function refresh() {
  renderTable();
  renderTimeline();
}

// ---- View Toggle ------------------------------------------------
function initViewToggle() {
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentView = btn.dataset.view;
      document.querySelectorAll('.view-panel').forEach(p => p.classList.remove('active'));
      document.getElementById(`view-${currentView}`).classList.add('active');
    });
  });
}

// ---- Export mock ------------------------------------------------
function initExport() {
  document.getElementById('btnExport').addEventListener('click', () => showToast('Đang xuất báo cáo PDF... (demo)'));
  document.getElementById('btnPrint').addEventListener('click', () => { showToast('Đang chuẩn bị in...'); setTimeout(() => window.print(), 800); });
}

// ---- Modal close events -----------------------------------------
function initModal() {
  document.getElementById('btnCloseModal').addEventListener('click', closeModal);
  document.getElementById('modalBackdrop').addEventListener('click', e => {
    if (e.target === e.currentTarget) closeModal();
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
}

// ---- Init -------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  renderStats();
  renderTable();
  renderTimeline();
  initFilters();
  initViewToggle();
  initExport();
  initModal();

  // Animate stat bars after paint
  requestAnimationFrame(() => {
    document.querySelectorAll('.bar-fill').forEach(el => {
      const w = el.style.width;
      el.style.width = '0';
      setTimeout(() => el.style.width = w, 80);
    });
    document.querySelectorAll('.score-bar-fill').forEach(el => {
      const w = el.style.width;
      el.style.width = '0';
      setTimeout(() => el.style.width = w, 150);
    });
  });
});
