/**
 * AgriAI RiceSmart - Lịch Chăm Sóc Vụ Mùa (Care Calendar & Task Cockpit)
 * JavaScript Application Logic (script.js)
 */

document.addEventListener("DOMContentLoaded", () => {
  // ==========================================
  // 1. CƠ SỞ DỮ LIỆU MOCK VỤ MÙA & CÔNG VIỆC
  // ==========================================
  const CALENDAR_DATA = {
    A: {
      fieldId: "A",
      fieldName: "Ruộng A - OM5451 Vụ Đông Xuân 2025",
      sowingDate: "28/11/2024",
      harvestDate: "08/03/2025",
      ageDays: 38,
      totalDays: 100,
      currentStage: "Đẻ nhánh rộ (38/100 ngày)",
      stages: [
        { name: "Sạ & Mạ non", range: "0 - 15 ngày", status: "completed", pct: 15 },
        { name: "Đẻ nhánh rộ", range: "16 - 40 ngày", status: "active", pct: 40 },
        { name: "Làm đòng", range: "41 - 60 ngày", status: "upcoming", pct: 60 },
        { name: "Trổ bông", range: "61 - 75 ngày", status: "upcoming", pct: 75 },
        { name: "Chín & Thu hoạch", range: "76 - 100 ngày", status: "upcoming", pct: 100 }
      ],
      tasks: [
        {
          id: "T1",
          title: "Rút nước phơi ruộng nứt chân chim (Chu kỳ AWD đợt 2)",
          category: "water",
          categoryName: "Tưới tiêu AWD",
          badgeColor: "bg-sky-100 text-sky-800",
          date: "Hôm nay (38 ngày tuổi)",
          time: "06:30 - 09:00",
          priority: "high",
          priorityText: "Ưu tiên cao",
          assignee: "KS. Nguyễn Văn Nông",
          status: "in_progress",
          completed: false,
          notes: "Rút cạn đến khi mực nước ngầm dưới mặt đất 10-15cm (nhìn thấy vết nứt chân chim nhỏ) để giải phóng khí độc CH₄/H₂S và kích thích rễ ăn sâu."
        },
        {
          id: "T2",
          title: "Kiểm tra bẫy đèn thông minh & Mật độ rầy nâu lứa 2",
          category: "scout",
          categoryName: "Thăm đồng / Giám sát",
          badgeColor: "bg-purple-100 text-purple-800",
          date: "Hôm nay",
          time: "18:00 - 20:30",
          priority: "medium",
          priorityText: "Quan trọng",
          assignee: "Tổ Kỹ thuật HTX",
          status: "pending",
          completed: false,
          notes: "Theo dõi lượng rầy vào bẫy đèn trạm quan trắc số 2. Dự báo đỉnh rầy non nở rộ trong 3 ngày tới."
        },
        {
          id: "T3",
          title: "Chuẩn bị phân bón Đón đòng đợt 1 (Đạm + Kali Silic)",
          category: "fertilizer",
          categoryName: "Bón phân",
          badgeColor: "bg-emerald-100 text-emerald-800",
          date: "08/02 (40 ngày tuổi)",
          time: "06:00 - 08:30",
          priority: "high",
          priorityText: "Rất quan trọng",
          assignee: "Đội máy bay sạ/rải phân",
          status: "upcoming",
          completed: false,
          notes: "Sử dụng bảng so màu lá LCC kiểm tra trước khi bón. Liều lượng khuyến nghị: 45kg Urê + 50kg Kali Clorua/ha."
        },
        {
          id: "T4",
          title: "Phun phòng đạo ôn cổ bông và đốm nâu bằng Drone",
          category: "pest",
          categoryName: "Bảo vệ thực vật",
          badgeColor: "bg-amber-100 text-amber-800",
          date: "10/02 (42 ngày tuổi)",
          time: "07:00 - 09:30",
          priority: "medium",
          priorityText: "Khuyến cáo AI",
          assignee: "Tổ bay Drone HTX Thới Lai",
          status: "upcoming",
          completed: false,
          notes: "Thời tiết ẩm sáng có sương mù nhẹ. Sử dụng hoạt chất Tricyclazole + vi lượng Kẽm Zn để tăng độ dày vách tế bào lá."
        },
        {
          id: "T5",
          title: "Bơm bổ sung nước trở lại ngập nông 3 - 5cm",
          category: "water",
          categoryName: "Tưới tiêu AWD",
          badgeColor: "bg-sky-100 text-sky-800",
          date: "12/02 (44 ngày tuổi)",
          time: "05:30 - 11:00",
          priority: "medium",
          priorityText: "AWD Chu kỳ mới",
          assignee: "Trạm bơm Kênh Đông",
          status: "upcoming",
          completed: false,
          notes: "Mở van cống số 1 đưa nước phù sa ngọt vào ruộng giữ ẩm nuôi đòng non."
        },
        {
          id: "T6",
          title: "Bón thúc đợt 1 (Đẻ nhánh) - Hỗn hợp NPK 20-20-15",
          category: "fertilizer",
          categoryName: "Bón phân",
          badgeColor: "bg-emerald-100 text-emerald-800",
          date: "15/12/2024 (18 ngày tuổi)",
          time: "06:00 - 08:00",
          priority: "high",
          priorityText: "Hoàn tất",
          assignee: "Tổ canh tác Ruộng A",
          status: "done",
          completed: true,
          notes: "Đã bón đồng đều toàn bộ 4.2 ha. Tỉ lệ đẻ nhánh đạt 180 dảnh/m² sau 5 ngày."
        },
        {
          id: "T7",
          title: "Làm cỏ bờ và dọn rong rêu cửa cống dẫn nước",
          category: "scout",
          categoryName: "Vệ sinh đồng ruộng",
          badgeColor: "bg-purple-100 text-purple-800",
          date: "22/12/2024 (25 ngày tuổi)",
          time: "07:00 - 10:00",
          priority: "low",
          priorityText: "Hoàn tất",
          assignee: "KS. Nguyễn Văn Nông",
          status: "done",
          completed: true,
          notes: "Đã phát quang bờ bao ngăn chuột cắn phá và diệt trừ ký chủ phụ của rầy."
        }
      ]
    },
    B: {
      fieldId: "B",
      fieldName: "Ruộng B - ST25 Vụ Đông Xuân 2025",
      sowingDate: "20/11/2024",
      harvestDate: "05/03/2025",
      ageDays: 46,
      totalDays: 105,
      currentStage: "Cuối đẻ nhánh - Chuẩn bị đón đòng (46/105 ngày)",
      stages: [
        { name: "Sạ & Mạ non", range: "0 - 15 ngày", status: "completed", pct: 14 },
        { name: "Đẻ nhánh", range: "16 - 42 ngày", status: "completed", pct: 40 },
        { name: "Làm đòng", range: "43 - 65 ngày", status: "active", pct: 62 },
        { name: "Trổ bông", range: "66 - 80 ngày", status: "upcoming", pct: 76 },
        { name: "Chín & Thu hoạch", range: "81 - 105 ngày", status: "upcoming", pct: 100 }
      ],
      tasks: [
        {
          id: "TB1",
          title: "Phun đặc trị nấm đạo ôn lá tại Lô B2",
          category: "pest",
          categoryName: "Bảo vệ thực vật",
          badgeColor: "bg-red-100 text-red-800",
          date: "Hôm nay (Khẩn cấp)",
          time: "15:30 - 17:30",
          priority: "high",
          priorityText: "Khẩn cấp 24h",
          assignee: "Đội Drone Cờ Đỏ",
          status: "in_progress",
          completed: false,
          notes: "Phun bao vây khoanh vùng vết bệnh hình thoi ở Lô B2. Hoạt chất Isoprothiolane."
        },
        {
          id: "TB2",
          title: "Bón phân đón đòng đợt 1 (ST25 chuyên dùng)",
          category: "fertilizer",
          categoryName: "Bón phân",
          badgeColor: "bg-emerald-100 text-emerald-800",
          date: "09/02 (49 ngày tuổi)",
          time: "06:00 - 08:30",
          priority: "high",
          priorityText: "Rất quan trọng",
          assignee: "Tổ kỹ thuật Cờ Đỏ",
          status: "upcoming",
          completed: false,
          notes: "Tăng tỷ lệ Kali và Silic để chống đổ ngã do ST25 thân cao rạ yếu."
        }
      ]
    },
    C: {
      fieldId: "C",
      fieldName: "Ruộng C - Đài Thơm 8 Vụ Đông Xuân 2025",
      sowingDate: "05/12/2024",
      harvestDate: "18/03/2025",
      ageDays: 31,
      totalDays: 95,
      currentStage: "Đang đẻ nhánh (31/95 ngày)",
      stages: [
        { name: "Sạ & Mạ non", range: "0 - 15 ngày", status: "completed", pct: 15 },
        { name: "Đẻ nhánh", range: "16 - 38 ngày", status: "active", pct: 40 },
        { name: "Làm đòng", range: "39 - 58 ngày", status: "upcoming", pct: 61 },
        { name: "Trổ bông", range: "59 - 72 ngày", status: "upcoming", pct: 76 },
        { name: "Chín & Thu hoạch", range: "73 - 95 ngày", status: "upcoming", pct: 100 }
      ],
      tasks: [
        {
          id: "TC1",
          title: "Tỉa dặm bổ sung các điểm sạ bị thưa tại Lô C2",
          category: "scout",
          categoryName: "Chăm sóc mạ",
          badgeColor: "bg-purple-100 text-purple-800",
          date: "Hôm nay",
          time: "07:00 - 10:00",
          priority: "medium",
          priorityText: "Cần làm",
          assignee: "Tổ phụ nữ HTX Vĩnh Thạnh",
          status: "in_progress",
          completed: false,
          notes: "Dặm đều các khoảnh trống để đảm bảo mật độ 200 chồi/m²."
        },
        {
          id: "TC2",
          title: "Bón thúc đợt 2 kích đẻ nhánh tối đa",
          category: "fertilizer",
          categoryName: "Bón phân",
          badgeColor: "bg-emerald-100 text-emerald-800",
          date: "08/02 (33 ngày tuổi)",
          time: "06:30 - 08:30",
          priority: "high",
          priorityText: "Ưu tiên cao",
          assignee: "Đội Drone",
          status: "upcoming",
          completed: false,
          notes: "Phối hợp NPK 16-16-8 + Hữu cơ sinh học Acid Humic."
        }
      ]
    }
  };

  // State
  let currentFieldKey = "A";
  let currentCategoryFilter = "all";
  let currentViewMode = "checklist"; // 'checklist' or 'weekly'

  // DOM Elements
  const fieldSelect = document.getElementById("fieldSelect");
  const fieldTitle = document.getElementById("fieldTitle");
  const cropStageText = document.getElementById("cropStageText");
  const timelineProgressBar = document.getElementById("timelineProgressBar");
  const stagesContainer = document.getElementById("stagesContainer");

  // KPI Metrics
  const metricCompletionRate = document.getElementById("metricCompletionRate");
  const metricPendingCount = document.getElementById("metricPendingCount");
  const metricWaterSaved = document.getElementById("metricWaterSaved");
  const metricFertilizerOptimized = document.getElementById("metricFertilizerOptimized");

  // Task List Container & Filters
  const taskListContainer = document.getElementById("taskListContainer");
  const categoryFilterBtns = document.querySelectorAll(".category-filter-btn");

  // View Switchers
  const btnViewChecklist = document.getElementById("btnViewChecklist");
  const btnViewWeekly = document.getElementById("btnViewWeekly");
  const viewChecklistContainer = document.getElementById("viewChecklistContainer");
  const viewWeeklyContainer = document.getElementById("viewWeeklyContainer");
  const weeklyGridDays = document.getElementById("weeklyGridDays");

  // Modals & Actions
  const btnOpenAddTaskModal = document.getElementById("btnOpenAddTaskModal");
  const addTaskModal = document.getElementById("addTaskModal");
  const btnCloseTaskModal = document.getElementById("btnCloseTaskModal");
  const formAddTask = document.getElementById("formAddTask");

  const btnSyncCalendar = document.getElementById("btnSyncCalendar");
  const btnExportCalendarPdf = document.getElementById("btnExportCalendarPdf");
  const toastNotification = document.getElementById("toastNotification");
  const toastMessage = document.getElementById("toastMessage");

  // ==========================================
  // 2. HELPER FUNCTIONS
  // ==========================================
  function showToast(msg) {
    if (!toastNotification || !toastMessage) return;
    toastMessage.textContent = msg;
    toastNotification.classList.remove("translate-y-24", "opacity-0");
    toastNotification.classList.add("translate-y-0", "opacity-100");
    setTimeout(() => {
      toastNotification.classList.remove("translate-y-0", "opacity-100");
      toastNotification.classList.add("translate-y-24", "opacity-0");
    }, 3200);
  }

  // ==========================================
  // 3. RENDER FUNCTIONS
  // ==========================================
  function renderAll() {
    const data = CALENDAR_DATA[currentFieldKey] || CALENDAR_DATA.A;

    // Header Titles
    if (fieldTitle) fieldTitle.textContent = data.fieldName;
    if (cropStageText) cropStageText.textContent = `Pha: ${data.currentStage} • Sạ: ${data.sowingDate} • Dự kiến thu hoạch: ${data.harvestDate}`;

    // Timeline Fill Pct
    const currentPct = Math.min(Math.round((data.ageDays / data.totalDays) * 100), 100);
    if (timelineProgressBar) {
      timelineProgressBar.style.width = `${currentPct}%`;
    }

    // Render Stages Markers
    if (stagesContainer) {
      stagesContainer.innerHTML = data.stages
        .map((stage) => {
          const isCurrent = stage.status === "active";
          const isDone = stage.status === "completed";
          return `
            <div class="flex flex-col items-center text-center">
              <div class="w-6 h-6 rounded-full flex items-center justify-center text-white text-[12px] font-bold ${
                isCurrent
                  ? "bg-secondary timeline-node active-stage"
                  : isDone
                  ? "bg-primary"
                  : "bg-surface-container-high text-on-surface-variant"
              }">
                ${isDone ? '<span class="material-symbols-outlined text-[14px]">done</span>' : isCurrent ? "★" : "○"}
              </div>
              <span class="font-label-sm text-label-sm mt-1 ${isCurrent ? "font-bold text-primary" : "text-on-surface-variant"}">
                ${stage.name}
              </span>
              <span class="text-[10px] font-telemetry-code text-on-surface-variant">${stage.range}</span>
            </div>
          `;
        })
        .join("");
    }

    // Render KPIs
    const completedTasks = data.tasks.filter((t) => t.completed).length;
    const totalTasks = data.tasks.length;
    const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    const pendingTasks = totalTasks - completedTasks;

    if (metricCompletionRate) metricCompletionRate.textContent = `${completionRate}%`;
    if (metricPendingCount) metricPendingCount.textContent = `${pendingTasks} việc`;
    if (metricWaterSaved) metricWaterSaved.textContent = "28%";
    if (metricFertilizerOptimized) metricFertilizerOptimized.textContent = "22%";

    // Render Views
    renderTaskList(data.tasks, currentCategoryFilter);
    renderWeeklyView(data.tasks);
  }

  function renderTaskList(tasks, categoryFilter) {
    if (!taskListContainer) return;

    let filtered = tasks;
    if (categoryFilter !== "all") {
      filtered = tasks.filter((t) => t.category === categoryFilter);
    }

    if (filtered.length === 0) {
      taskListContainer.innerHTML = `
        <div class="py-12 text-center text-on-surface-variant font-body-md bg-surface-container-low/40 rounded-2xl">
          <span class="material-symbols-outlined text-[36px] text-outline-variant mb-1">event_busy</span>
          <p>Không có công việc nào thuộc danh mục này.</p>
        </div>
      `;
      return;
    }

    taskListContainer.innerHTML = filtered
      .map((task) => {
        return `
        <div class="task-item bg-surface-container-lowest border border-outline-variant/30 rounded-2xl p-space-md shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-space-md ${
          task.completed ? "completed" : ""
        }" data-task-id="${task.id}">
          <div class="flex items-start gap-3.5">
            <!-- Custom Checkbox -->
            <input type="checkbox" class="task-checkbox mt-1 shrink-0" data-id="${task.id}" ${task.completed ? "checked" : ""}/>

            <div class="space-y-1">
              <div class="flex flex-wrap items-center gap-2">
                <span class="font-label-sm text-label-sm px-2.5 py-0.5 rounded-full ${task.badgeColor} font-semibold">
                  ${task.categoryName}
                </span>
                <span class="font-telemetry-code text-[11px] px-2 py-0.5 rounded-full ${
                  task.priority === "high"
                    ? "bg-red-100 text-error font-bold"
                    : task.priority === "medium"
                    ? "bg-amber-100 text-amber-800"
                    : "bg-surface-container-high text-on-surface-variant"
                }">
                  ${task.priorityText}
                </span>
                <span class="text-on-surface-variant text-[12px] flex items-center gap-1">
                  <span class="material-symbols-outlined text-[14px]">schedule</span>
                  ${task.date} (${task.time})
                </span>
              </div>

              <h4 class="task-title font-headline-sm text-headline-sm text-on-surface font-semibold">
                ${task.title}
              </h4>

              <p class="font-body-sm text-body-sm text-on-surface-variant line-clamp-2">
                ${task.notes}
              </p>
            </div>
          </div>

          <div class="flex items-center gap-3 self-end sm:self-center shrink-0 pt-2 sm:pt-0">
            <div class="text-right hidden md:block">
              <span class="font-label-sm text-label-sm text-on-surface font-medium block">${task.assignee}</span>
              <span class="text-[11px] font-telemetry-code text-on-surface-variant">Phân công</span>
            </div>
            <button type="button" class="btn-delete-task p-2 rounded-xl text-on-surface-variant hover:text-error hover:bg-error-container/30 transition-colors" data-id="${task.id}" title="Xóa tác vụ">
              <span class="material-symbols-outlined text-[18px]">delete</span>
            </button>
          </div>
        </div>
      `;
      })
      .join("");

    // Attach checkbox events
    taskListContainer.querySelectorAll(".task-checkbox").forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const taskId = e.target.getAttribute("data-id");
        toggleTaskCompletion(taskId, e.target.checked);
      });
    });

    // Attach delete events
    taskListContainer.querySelectorAll(".btn-delete-task").forEach((btn) => {
      btn.addEventListener("click", () => {
        const taskId = btn.getAttribute("data-id");
        deleteTask(taskId);
      });
    });
  }

  function renderWeeklyView(tasks) {
    if (!weeklyGridDays) return;

    // 7 days mock week: T2 to CN
    const days = [
      { dayName: "Thứ 2 (03/2)", dateKey: "T2", isToday: false },
      { dayName: "Thứ 3 (04/2)", dateKey: "T3", isToday: false },
      { dayName: "Thứ 4 (Hôm nay)", dateKey: "Hôm nay", isToday: true },
      { dayName: "Thứ 5 (06/2)", dateKey: "T5", isToday: false },
      { dayName: "Thứ 6 (07/2)", dateKey: "T6", isToday: false },
      { dayName: "Thứ 7 (08/2)", dateKey: "08/2", isToday: false },
      { dayName: "Chủ Nhật (09/2)", dateKey: "09/2", isToday: false }
    ];

    weeklyGridDays.innerHTML = days
      .map((d) => {
        // Find tasks containing day keyword
        const dayTasks = tasks.filter((t) => t.date.includes(d.dateKey) || (d.isToday && t.date.includes("Hôm nay")));

        return `
        <div class="cal-day-cell min-h-[160px] p-3 rounded-2xl border border-outline-variant/30 flex flex-col justify-between ${
          d.isToday ? "today-cell" : "bg-surface-container-lowest"
        }">
          <div>
            <div class="flex items-center justify-between pb-2 mb-2 border-b border-outline-variant/20">
              <span class="font-label-sm text-label-sm ${d.isToday ? "font-bold text-primary" : "text-on-surface-variant"}">
                ${d.dayName}
              </span>
              ${d.isToday ? '<span class="w-2 h-2 rounded-full bg-secondary animate-ping"></span>' : ""}
            </div>

            <!-- Tasks in this day -->
            <div class="space-y-1.5">
              ${
                dayTasks.length > 0
                  ? dayTasks
                      .map(
                        (t) => `
                    <div class="p-1.5 rounded-lg text-[11px] ${t.badgeColor} font-medium line-clamp-2 cursor-pointer hover:opacity-85 shadow-2xs" title="${t.title}">
                      ${t.title}
                    </div>
                  `
                      )
                      .join("")
                  : '<span class="text-[11px] text-on-surface-variant/70 italic">Không có lịch</span>'
              }
            </div>
          </div>

          <div class="pt-2 text-right">
            <span class="text-[10px] font-telemetry-code text-on-surface-variant">${dayTasks.length} tác vụ</span>
          </div>
        </div>
      `;
      })
      .join("");
  }

  // ==========================================
  // 4. TASK OPERATIONS
  // ==========================================
  function toggleTaskCompletion(taskId, isCompleted) {
    const data = CALENDAR_DATA[currentFieldKey];
    if (!data) return;
    const task = data.tasks.find((t) => t.id === taskId);
    if (task) {
      task.completed = isCompleted;
      task.status = isCompleted ? "done" : "in_progress";
      renderAll();
      showToast(isCompleted ? `Đã hoàn thành: "${task.title}"` : `Đã chuyển sang chưa hoàn thành: "${task.title}"`);
    }
  }

  function deleteTask(taskId) {
    const data = CALENDAR_DATA[currentFieldKey];
    if (!data) return;
    const idx = data.tasks.findIndex((t) => t.id === taskId);
    if (idx !== -1) {
      const removed = data.tasks.splice(idx, 1)[0];
      renderAll();
      showToast(`Đã xóa công việc: "${removed.title}"`);
    }
  }

  // ==========================================
  // 5. EVENT LISTENERS
  // ==========================================
  // Field selection change
  if (fieldSelect) {
    fieldSelect.addEventListener("change", (e) => {
      currentFieldKey = e.target.value;
      renderAll();
      showToast(`Đã chuyển lịch sang ${CALENDAR_DATA[currentFieldKey]?.fieldName}`);
    });
  }

  // Category Filter
  categoryFilterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      categoryFilterBtns.forEach((b) => {
        b.classList.remove("bg-primary", "text-on-primary", "shadow-sm");
        b.classList.add("bg-surface-container-low", "text-on-surface-variant");
      });
      btn.classList.add("bg-primary", "text-on-primary", "shadow-sm");
      btn.classList.remove("bg-surface-container-low", "text-on-surface-variant");

      currentCategoryFilter = btn.getAttribute("data-category") || "all";
      renderTaskList(CALENDAR_DATA[currentFieldKey].tasks, currentCategoryFilter);
    });
  });

  // Switch View Mode: Checklist vs Weekly Grid
  if (btnViewChecklist) {
    btnViewChecklist.addEventListener("click", () => {
      currentViewMode = "checklist";
      btnViewChecklist.classList.add("bg-primary", "text-on-primary", "shadow-sm");
      btnViewChecklist.classList.remove("bg-surface-container-low", "text-on-surface-variant");

      btnViewWeekly?.classList.remove("bg-primary", "text-on-primary", "shadow-sm");
      btnViewWeekly?.classList.add("bg-surface-container-low", "text-on-surface-variant");

      viewChecklistContainer?.classList.remove("hidden");
      viewWeeklyContainer?.classList.add("hidden");
    });
  }

  if (btnViewWeekly) {
    btnViewWeekly.addEventListener("click", () => {
      currentViewMode = "weekly";
      btnViewWeekly.classList.add("bg-primary", "text-on-primary", "shadow-sm");
      btnViewWeekly.classList.remove("bg-surface-container-low", "text-on-surface-variant");

      btnViewChecklist?.classList.remove("bg-primary", "text-on-primary", "shadow-sm");
      btnViewChecklist?.classList.add("bg-surface-container-low", "text-on-surface-variant");

      viewWeeklyContainer?.classList.remove("hidden");
      viewChecklistContainer?.classList.add("hidden");
    });
  }

  // Modal: Add Task
  if (btnOpenAddTaskModal && addTaskModal) {
    btnOpenAddTaskModal.addEventListener("click", () => {
      addTaskModal.classList.remove("hidden");
    });
  }

  if (btnCloseTaskModal && addTaskModal) {
    btnCloseTaskModal.addEventListener("click", () => {
      addTaskModal.classList.add("hidden");
    });
  }

  if (formAddTask) {
    formAddTask.addEventListener("submit", (e) => {
      e.preventDefault();
      const title = document.getElementById("taskTitleInput")?.value || "";
      const category = document.getElementById("taskCategoryInput")?.value || "fertilizer";
      const date = document.getElementById("taskDateInput")?.value || "Hôm nay";
      const time = document.getElementById("taskTimeInput")?.value || "06:30 - 08:30";
      const priority = document.getElementById("taskPriorityInput")?.value || "medium";
      const assignee = document.getElementById("taskAssigneeInput")?.value || "KS. Nguyễn Văn Nông";
      const notes = document.getElementById("taskNotesInput")?.value || "";

      let categoryName = "Bón phân";
      let badgeColor = "bg-emerald-100 text-emerald-800";
      if (category === "water") {
        categoryName = "Tưới tiêu AWD";
        badgeColor = "bg-sky-100 text-sky-800";
      } else if (category === "pest") {
        categoryName = "Bảo vệ thực vật";
        badgeColor = "bg-amber-100 text-amber-800";
      } else if (category === "scout") {
        categoryName = "Thăm đồng / Giám sát";
        badgeColor = "bg-purple-100 text-purple-800";
      }

      const newTask = {
        id: `T-${Date.now().toString().slice(-4)}`,
        title,
        category,
        categoryName,
        badgeColor,
        date,
        time,
        priority,
        priorityText: priority === "high" ? "Ưu tiên cao" : priority === "medium" ? "Quan trọng" : "Thường",
        assignee,
        status: "upcoming",
        completed: false,
        notes
      };

      CALENDAR_DATA[currentFieldKey].tasks.unshift(newTask);
      renderAll();
      formAddTask.reset();
      addTaskModal?.classList.add("hidden");
      showToast(`Đã thêm mới công việc: "${title}"`);
    });
  }

  // Export PDF
  if (btnExportCalendarPdf) {
    btnExportCalendarPdf.addEventListener("click", () => {
      showToast(`Đã kết xuất Kế hoạch Lịch chăm sóc vụ ${CALENDAR_DATA[currentFieldKey]?.fieldName} (PDF).`);
    });
  }

  // Sync Calendar
  if (btnSyncCalendar) {
    btnSyncCalendar.addEventListener("click", () => {
      const icon = btnSyncCalendar.querySelector(".material-symbols-outlined");
      if (icon) icon.classList.add("animate-spin");
      setTimeout(() => {
        if (icon) icon.classList.remove("animate-spin");
        renderAll();
        showToast("Đã đồng bộ lịch trình mùa vụ với dữ liệu trạm IoT & Dự báo thời tiết!");
      }, 800);
    });
  }

  // INITIAL RUN
  renderAll();
});
