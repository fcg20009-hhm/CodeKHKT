/**
 * AgriAI RiceSmart - AI Chatbox Trợ Lý Nông Nghiệp
 * script.js - Tích hợp Google Gemini API (Model: Gemini 3.8 Flash & Multimodal Vision)
 */

(function () {
  'use strict';

  // 1. Cấu hình Google Gemini API
  const DEFAULT_GEMINI_API_KEY = 'AQ.Ab8RN6J7MbAK5RQBDbgmm8b98E7ZbqGOMu9PDGOZtRA0ha3aEw';
  const STORAGE_KEY = 'gemini_api_key';

  // Danh sách model theo thứ tự ưu tiên (Tự động fallback nếu model chính bận)
  const GEMINI_MODELS = [
    'gemini-3.8-flash',
    'gemini-3.5-flash',
    'gemini-3.1-flash-lite',
    'gemini-flash-latest'
  ];

  function getApiKey() {
    return localStorage.getItem(STORAGE_KEY) || DEFAULT_GEMINI_API_KEY;
  }

  function setApiKey(key) {
    if (key && key.trim()) {
      localStorage.setItem(STORAGE_KEY, key.trim());
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }

  // 2. Ngữ cảnh canh tác & Hệ thống Prompts
  let currentPlotContext = {
    name: 'Ruộng A',
    variety: 'OM5451',
    season: 'Đông Xuân 2025',
    area: '1.2 ha',
    ageDays: 42,
    stage: 'Làm đòng / Phân hóa đòng (chuẩn bị bón đón đòng đợt 3)',
    healthAvg: '88/100',
    waterAvg: '3.1 cm',
    ph: '6.2',
    criticalNotes: [
      'Lô A3: Sức khỏe giảm còn 61/100, mực nước cạn còn 1.2cm, độ ẩm 54%, chớm đốm nâu và vàng chóp lá sinh lý. Khuyến nghị bơm nước 3-4cm và phun bổ sung Kẽm (Zn-chelate).',
      'Lô B2: Cảm biến EC đo 1.1 mS/cm, có dấu hiệu tích tụ phèn nhẹ ở rễ lúa. Khuyến nghị thau chua rửa phèn.'
    ]
  };

  function buildSystemInstruction() {
    return `Bạn là "AgriAI Copilot", trợ lý chuyên gia nông học thông minh, am hiểu sâu sắc về kỹ thuật canh tác lúa nước tại Đồng bằng sông Cửu Long (đặc biệt là mô hình Hợp tác xã Nông nghiệp Cần Thơ).

Ngữ cảnh đồng ruộng hiện tại của người dùng (Kỹ sư / Nông dân Nguyễn Văn Nông):
- Ruộng đang theo dõi: ${currentPlotContext.name} (${currentPlotContext.area}), Giống lúa: ${currentPlotContext.variety}, Vụ mùa: ${currentPlotContext.season}.
- Tuổi lúa: ${currentPlotContext.ageDays} ngày tuổi - Giai đoạn: ${currentPlotContext.stage}.
- Các chỉ số môi trường: Điểm sức khỏe trung bình ${currentPlotContext.healthAvg}, mực nước trung bình ${currentPlotContext.waterAvg}, pH ${currentPlotContext.ph}.
- Cảnh báo thực địa cần lưu ý:
  + ${currentPlotContext.criticalNotes.join('\n  + ')}

Văn phong và quy tắc ứng xử:
1. Xưng hô lịch sự, gần gũi và tôn trọng: "anh Nông", "thưa anh".
2. Cung cấp kiến thức nông nghiệp chính xác, thực tiễn tại Việt Nam (liều lượng phân bón Urê, Kali Clorua, DAP, NPK, cách điều tiết nước ngập - khô xen kẽ AWD, các hoạt chất BVTV an toàn theo danh mục Bộ NN&PTNT).
3. Trình bày đẹp mắt, rõ ràng bằng Markdown: sử dụng gạch đầu dòng, **in đậm** các từ khóa, thông số hoặc tên thuốc/phân bón quan trọng.
4. Nếu người dùng gửi kèm ảnh lá lúa hoặc cây trồng, hãy đóng vai chuyên gia bệnh cây: nhận diện triệu chứng (đốm nâu, đạo ôn lá, cháy bìa lá do vi khuẩn, rầy nâu, thiếu kẽm/đạm...), phân tích nguyên nhân và hướng dẫn biện pháp khắc phục cụ thể.
5. Luôn trả lời bằng tiếng Việt chuẩn, súc tích, dễ hiểu và dễ áp dụng ngoài đồng ruộng.`;
  }

  // 3. Lịch sử hội thoại (Multi-turn chat context)
  let conversationHistory = [];

  // DOM Elements
  const chatStream = document.getElementById('chatStream');
  const chatForm = document.getElementById('chatForm');
  const chatInput = document.getElementById('chatInput');
  const chipContainer = document.getElementById('chipContainer');
  const typingIndicator = document.getElementById('aiTypingIndicator');
  const btnClearChat = document.getElementById('btnClearChat');
  const btnExportChat = document.getElementById('btnExportChat');
  const btnSwitchPlot = document.getElementById('btnSwitchPlot');
  const btnMicRecord = document.getElementById('btnMicRecord');
  const btnUploadLeaf = document.getElementById('btnUploadLeaf');
  const leafPhotoInput = document.getElementById('leafPhotoInput');
  const btnViewA3Photo = document.getElementById('btnViewA3Photo');
  const btnCreateWaterSchedule = document.getElementById('btnCreateWaterSchedule');
  const btnCloseImagePreview = document.getElementById('btnCloseImagePreview');
  const imagePreviewBox = document.getElementById('imagePreviewBox');
  const aiToast = document.getElementById('aiToast');
  const toastText = document.getElementById('toastText');

  // Image Attachment Elements in Input
  const attachedImageContainer = document.getElementById('attachedImageContainer');
  const attachedImageThumb = document.getElementById('attachedImageThumb');
  const attachedImageName = document.getElementById('attachedImageName');
  const btnRemoveAttachedImage = document.getElementById('btnRemoveAttachedImage');

  // Modal API Key Elements
  const btnApiKeySettings = document.getElementById('btnApiKeySettings');
  const apiKeyModal = document.getElementById('apiKeyModal');
  const btnCloseApiKeyModal = document.getElementById('btnCloseApiKeyModal');
  const apiKeyInput = document.getElementById('apiKeyInput');
  const btnToggleApiKeyVisibility = document.getElementById('btnToggleApiKeyVisibility');
  const eyeIcon = document.getElementById('eyeIcon');
  const btnResetDefaultApiKey = document.getElementById('btnResetDefaultApiKey');
  const btnSaveApiKey = document.getElementById('btnSaveApiKey');
  const geminiStatusBadge = document.getElementById('geminiStatusBadge');

  // State cho ảnh đang đính kèm
  let currentPendingImage = null; // { base64Data, mimeType, name, dataUrl }

  /**
   * Hiển thị thông báo Toast
   * @param {string} msg
   */
  function showToast(msg) {
    if (!aiToast || !toastText) return;
    toastText.textContent = msg;
    aiToast.classList.remove('translate-y-[-120%]', 'opacity-0');
    aiToast.classList.add('translate-y-0', 'opacity-100');
    setTimeout(() => {
      aiToast.classList.remove('translate-y-0', 'opacity-100');
      aiToast.classList.add('translate-y-[-120%]', 'opacity-0');
    }, 2800);
  }

  /**
   * Tự động cuộn khung chat xuống cuối
   */
  function scrollToBottom() {
    if (chatStream) {
      chatStream.scrollTop = chatStream.scrollHeight;
    }
  }

  /**
   * Thoát ký tự HTML an toàn
   */
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /**
   * Parser Markdown gọn gàng sang HTML tương thích với theme
   */
  function renderMarkdown(md) {
    if (!md) return '';

    let html = escapeHtml(md);

    // Code blocks ```lang ... ```
    html = html.replace(/```([\s\S]*?)```/g, (match, p1) => {
      return `<pre><code>${p1.trim()}</code></pre>`;
    });

    // Inline code `...`
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Headings
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');

    // Bold **text**
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/__(.*?)__/g, '<strong>$1</strong>');

    // Italic *text*
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

    // Blockquotes
    html = html.replace(/^\> (.*$)/gim, '<blockquote>$1</blockquote>');

    // Lists
    html = html.replace(/^\s*[-*]\s+(.*$)/gim, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>)/gms, '<ul>$1</ul>');
    // Dọn bớt các ul lồng trùng lặp
    html = html.replace(/<\/ul>\s*<ul>/g, '');

    // Numbered lists
    html = html.replace(/^\s*\d+\.\s+(.*$)/gim, '<li>$1</li>');

    // Đoạn văn Paragraphs
    const lines = html.split(/\n\n+/);
    html = lines
      .map((block) => {
        block = block.trim();
        if (!block) return '';
        if (
          block.startsWith('<h') ||
          block.startsWith('<ul') ||
          block.startsWith('<pre') ||
          block.startsWith('<blockquote')
        ) {
          return block;
        }
        return `<p>${block.replace(/\n/g, '<br/>')}</p>`;
      })
      .join('');

    return html;
  }

  /**
   * Thêm tin nhắn từ người dùng vào luồng chat
   * @param {string} text
   * @param {string} [attachedImageUrl]
   */
  function appendUserMessage(text, attachedImageUrl) {
    const timeStr = new Date().toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
    });
    const msgDiv = document.createElement('div');
    msgDiv.className =
      'flex items-start gap-space-sm max-w-2xl ml-auto flex-row-reverse animate-in fade-in duration-300 chat-message-enter';

    let imageHtml = '';
    if (attachedImageUrl) {
      imageHtml = `
        <div class="mt-2 mb-1 rounded-xl overflow-hidden max-w-xs border border-primary-container shadow-sm">
          <img src="${attachedImageUrl}" alt="Ảnh mẫu lá tải lên" class="w-full h-auto max-h-48 object-cover rounded-lg" />
        </div>
      `;
    }

    msgDiv.innerHTML = `
      <div class="w-8 h-8 rounded-xl bg-primary text-on-primary flex items-center justify-center shrink-0 shadow-sm mt-0.5">
        <span class="material-symbols-outlined text-[18px]">person</span>
      </div>
      <div class="flex flex-col items-end gap-1">
        <div class="flex items-center gap-2">
          <span class="font-telemetry-code text-[11px] text-on-surface-variant">${timeStr}</span>
          <span class="font-label-md text-label-md text-on-surface font-semibold">KS. Nguyễn Văn Nông</span>
        </div>
        <div class="bg-primary text-on-primary rounded-2xl rounded-tr-sm px-4 py-2.5 shadow-sm">
          ${imageHtml}
          ${text ? `<p class="font-body-md text-body-md">${escapeHtml(text)}</p>` : ''}
        </div>
      </div>
    `;
    chatStream.appendChild(msgDiv);
    scrollToBottom();
  }

  /**
   * Thêm phản hồi của AI Copilot vào luồng chat
   * @param {string} markdownContent
   * @param {string} [modelUsed]
   */
  function appendAIMessage(markdownContent, modelUsed = 'Gemini 3.8 Flash') {
    const timeStr = new Date().toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
    });
    const msgDiv = document.createElement('div');
    msgDiv.className =
      'flex items-start gap-space-sm max-w-3xl animate-in fade-in duration-300 chat-message-enter';
    msgDiv.innerHTML = `
      <div class="w-8 h-8 rounded-xl bg-primary-container text-on-primary-container flex items-center justify-center shrink-0 shadow-sm mt-0.5">
        <span class="material-symbols-outlined text-[18px]">psychology</span>
      </div>
      <div class="flex flex-col gap-1 w-full max-w-2xl">
        <div class="flex items-center gap-2">
          <span class="font-label-md text-label-md text-on-surface font-semibold">AgriAI Copilot</span>
          <span class="font-telemetry-code text-[11px] text-on-surface-variant">${timeStr}</span>
          <span class="bg-secondary-container text-on-secondary-container text-label-sm font-label-sm px-1.5 py-0.2 rounded">${escapeHtml(modelUsed)}</span>
        </div>
        <div class="bg-surface-container-lowest text-on-surface rounded-2xl rounded-tl-sm p-4 shadow-sm space-y-2 ai-markdown">
          ${renderMarkdown(markdownContent)}
        </div>
      </div>
    `;
    chatStream.appendChild(msgDiv);
    scrollToBottom();
  }

  /**
   * Thêm thông báo lỗi vào chat với nút thử lại
   */
  function appendErrorMessage(errorMsg, onRetry) {
    const msgDiv = document.createElement('div');
    msgDiv.className =
      'flex items-start gap-space-sm max-w-3xl animate-in fade-in duration-300 chat-message-enter';
    msgDiv.innerHTML = `
      <div class="w-8 h-8 rounded-xl bg-error-container text-error flex items-center justify-center shrink-0 shadow-sm mt-0.5">
        <span class="material-symbols-outlined text-[18px]">error</span>
      </div>
      <div class="flex flex-col gap-1 w-full max-w-2xl">
        <div class="flex items-center gap-2">
          <span class="font-label-md text-label-md text-error font-semibold">Thông báo hệ thống</span>
        </div>
        <div class="bg-surface-container-lowest border border-error/30 text-on-surface rounded-2xl rounded-tl-sm p-4 shadow-sm space-y-2">
          <p class="font-body-md text-body-md text-error">${escapeHtml(errorMsg)}</p>
          <div class="flex items-center gap-2 pt-1">
            <button class="retry-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-error/10 hover:bg-error/20 text-error font-label-md text-label-md transition-colors">
              <span class="material-symbols-outlined text-[16px]">refresh</span>
              Thử lại
            </button>
            <button class="config-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md transition-colors">
              <span class="material-symbols-outlined text-[16px]">key</span>
              Kiểm tra API Key
            </button>
          </div>
        </div>
      </div>
    `;

    const retryBtn = msgDiv.querySelector('.retry-btn');
    if (retryBtn && onRetry) {
      retryBtn.addEventListener('click', () => {
        msgDiv.remove();
        onRetry();
      });
    }

    const configBtn = msgDiv.querySelector('.config-btn');
    if (configBtn) {
      configBtn.addEventListener('click', () => {
        openApiKeyModal();
      });
    }

    chatStream.appendChild(msgDiv);
    scrollToBottom();
  }

  /**
   * Gọi Google Gemini API với cơ chế tự động Fallback các model
   * @param {Array} userParts mảng các parts của user
   * @returns {Promise<{text: string, modelName: string}>}
   */
  async function requestGeminiAPI(userParts) {
    const apiKey = getApiKey();
    if (!apiKey) {
      throw new Error('Chưa thiết lập Gemini API Key. Vui lòng nhấn vào "Cấu hình API" ở thanh trên để nhập khóa.');
    }

    // Chuẩn bị payload theo đúng chuẩn Google Generative Language API
    const contents = [
      ...conversationHistory,
      {
        role: 'user',
        parts: userParts,
      },
    ];

    const bodyPayload = {
      systemInstruction: {
        parts: [{ text: buildSystemInstruction() }],
      },
      contents: contents,
      generationConfig: {
        temperature: 0.7,
        topP: 0.95,
        maxOutputTokens: 2048,
      },
    };

    let lastError = null;

    // Duyệt qua danh sách các model để dự phòng nếu gặp tải cao (503/429/404)
    for (const model of GEMINI_MODELS) {
      try {
        const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(bodyPayload),
        });

        const data = await response.json();

        if (response.ok && data.candidates && data.candidates.length > 0) {
          const candidate = data.candidates[0];
          const textReply = candidate.content?.parts?.map((p) => p.text).join('') || '';

          // Cập nhật lại lịch sử hội thoại
          conversationHistory.push({
            role: 'user',
            parts: userParts,
          });
          conversationHistory.push({
            role: 'model',
            parts: [{ text: textReply }],
          });

          // Giới hạn độ dài lịch sử tránh tràn token
          if (conversationHistory.length > 20) {
            conversationHistory = conversationHistory.slice(conversationHistory.length - 20);
          }

          return {
            text: textReply,
            modelName: model,
          };
        }

        // Nếu API trả về lỗi
        if (data.error) {
          const code = data.error.code;
          const msg = data.error.message || 'Lỗi không xác định từ Gemini API';
          console.warn(`Gemini Model ${model} gặp lỗi (${code}):`, msg);

          // Nếu model quá tải hoặc không khả dụng, tiếp tục thử model tiếp theo
          if (code === 503 || code === 404 || code === 429) {
            lastError = new Error(`Model ${model}: ${msg}`);
            continue;
          }

          throw new Error(`Gemini API Error: ${msg}`);
        }

        throw new Error('Không nhận được phản hồi hợp lệ từ Gemini API.');
      } catch (err) {
        lastError = err;
        console.warn(`Lỗi khi gọi model ${model}:`, err);
      }
    }

    throw lastError || new Error('Không thể kết nối đến máy chủ Google Gemini. Vui lòng kiểm tra lại kết nối mạng hoặc API Key.');
  }

  /**
   * Xử lý gửi tin nhắn của người dùng kèm ảnh nếu có
   */
  async function handleSend(userText, imageInfo = null) {
    const text = (userText || '').trim();
    const hasImage = Boolean(imageInfo || currentPendingImage);
    const activeImage = imageInfo || currentPendingImage;

    if (!text && !hasImage) return;

    // Reset giao diện pending image
    if (currentPendingImage) {
      clearPendingImage();
    }
    if (chatInput) chatInput.value = '';

    // 1. Hiển thị tin nhắn người dùng lên khung chat
    appendUserMessage(text, activeImage ? activeImage.dataUrl : null);

    // 2. Chuẩn bị parts gửi tới Gemini
    const parts = [];
    if (text) {
      parts.push({ text: text });
    }
    if (activeImage) {
      parts.push({
        inline_data: {
          mime_type: activeImage.mimeType,
          data: activeImage.base64Data,
        },
      });
      if (!text) {
        parts.unshift({
          text: 'Tôi gửi ảnh mẫu lá lúa thực địa này từ đồng ruộng. Xin chuyên gia chẩn đoán các triệu chứng sâu bệnh hoặc thiếu dinh dưỡng trên lá, đánh giá mức độ và đề xuất giải pháp xử lý kỹ thuật kịp thời.',
        });
      }
    }

    // 3. Hiển thị hiệu ứng AI đang phân tích
    if (typingIndicator) {
      typingIndicator.classList.remove('hidden');
    }
    scrollToBottom();

    // 4. Gọi API Gemini
    try {
      const result = await requestGeminiAPI(parts);
      if (typingIndicator) {
        typingIndicator.classList.add('hidden');
      }
      appendAIMessage(result.text, result.modelName);
    } catch (err) {
      if (typingIndicator) {
        typingIndicator.classList.add('hidden');
      }
      appendErrorMessage(err.message, () => handleSend(text, activeImage));
    }
  }

  /**
   * Đặt ảnh chờ gửi
   */
  function setPendingImage(file) {
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Vui lòng chọn một tệp hình ảnh hợp lệ (JPG, PNG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
      const dataUrl = e.target.result;
      const base64Data = dataUrl.split(',')[1];

      currentPendingImage = {
        name: file.name,
        mimeType: file.type,
        base64Data: base64Data,
        dataUrl: dataUrl,
      };

      if (attachedImageContainer && attachedImageThumb && attachedImageName) {
        attachedImageThumb.src = dataUrl;
        attachedImageName.textContent = file.name;
        attachedImageContainer.classList.remove('hidden');
      }

      showToast(`Đã đính kèm ảnh "${file.name}". Bấm gửi để AI phân tích!`);
      if (chatInput) {
        chatInput.focus();
      }
    };
    reader.readAsDataURL(file);
  }

  /**
   * Xóa ảnh chờ gửi
   */
  function clearPendingImage() {
    currentPendingImage = null;
    if (attachedImageContainer) {
      attachedImageContainer.classList.add('hidden');
    }
    if (attachedImageThumb) {
      attachedImageThumb.src = '';
    }
    if (leafPhotoInput) {
      leafPhotoInput.value = '';
    }
  }

  /**
   * Quản lý Modal Cấu hình API Key
   */
  function openApiKeyModal() {
    if (!apiKeyModal) return;
    if (apiKeyInput) {
      apiKeyInput.value = getApiKey();
    }
    apiKeyModal.classList.remove('hidden');
  }

  function closeApiKeyModal() {
    if (!apiKeyModal) return;
    apiKeyModal.classList.add('hidden');
  }

  // Khởi tạo các sự kiện khi DOM sẵn sàng
  document.addEventListener('DOMContentLoaded', () => {
    // 1. Submit Form chat
    if (chatForm) {
      chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = chatInput ? chatInput.value : '';
        handleSend(text);
      });
    }

    // 2. Chip gợi ý truy vấn nhanh
    if (chipContainer) {
      chipContainer.addEventListener('click', (e) => {
        const chip = e.target.closest('.prompt-chip');
        if (chip) {
          const text = chip.getAttribute('data-prompt');
          if (text) {
            handleSend(text);
          }
        }
      });
    }

    // 3. Tải ảnh kiểm tra bệnh lá lúa qua Gemini Vision
    if (btnUploadLeaf && leafPhotoInput) {
      btnUploadLeaf.addEventListener('click', () => {
        leafPhotoInput.click();
      });

      leafPhotoInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          setPendingImage(e.target.files[0]);
        }
      });
    }

    // Nút hủy ảnh đính kèm
    if (btnRemoveAttachedImage) {
      btnRemoveAttachedImage.addEventListener('click', () => {
        clearPendingImage();
        showToast('Đã hủy ảnh đính kèm.');
      });
    }

    // 4. Ghi âm giọng nói (Web Speech API)
    let recognition = null;
    let isRecording = false;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'vi-VN';

      recognition.onstart = () => {
        isRecording = true;
        const icon = document.getElementById('micIcon');
        if (icon) icon.classList.add('text-error', 'animate-pulse');
        if (chatInput) {
          chatInput.placeholder = 'Đang lắng nghe giọng nói của anh...';
        }
        showToast('Micro đang thu âm tiếng Việt...');
      };

      recognition.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        if (chatInput) {
          chatInput.value = transcript;
        }
      };

      recognition.onerror = (event) => {
        console.warn('Speech recognition error:', event.error);
        isRecording = false;
        const icon = document.getElementById('micIcon');
        if (icon) icon.classList.remove('text-error', 'animate-pulse');
        if (chatInput) {
          chatInput.placeholder = 'Hỏi AgriAI về sâu bệnh, phân bón, thời tiết, tình trạng ruộng...';
        }
      };

      recognition.onend = () => {
        isRecording = false;
        const icon = document.getElementById('micIcon');
        if (icon) icon.classList.remove('text-error', 'animate-pulse');
        if (chatInput) {
          chatInput.placeholder = 'Hỏi AgriAI về sâu bệnh, phân bón, thời tiết, tình trạng ruộng...';
        }
      };
    }

    if (btnMicRecord) {
      btnMicRecord.addEventListener('click', () => {
        if (!recognition) {
          // Fallback giả lập nếu trình duyệt không hỗ trợ Web Speech
          if (chatInput) {
            chatInput.value = 'Khu vực B2 có bị tích tụ phèn không và biện pháp xử lý là gì?';
            showToast('Đã chèn câu hỏi mẫu bằng giọng nói!');
          }
          return;
        }

        if (isRecording) {
          recognition.stop();
        } else {
          try {
            recognition.start();
          } catch (e) {
            console.warn(e);
          }
        }
      });
    }

    // 5. Cấu hình API Key Modal
    if (btnApiKeySettings) {
      btnApiKeySettings.addEventListener('click', openApiKeyModal);
    }
    if (btnCloseApiKeyModal) {
      btnCloseApiKeyModal.addEventListener('click', closeApiKeyModal);
    }
    if (apiKeyModal) {
      apiKeyModal.addEventListener('click', (e) => {
        if (e.target === apiKeyModal) closeApiKeyModal();
      });
    }

    // Ẩn/Hiện mật khẩu API Key
    if (btnToggleApiKeyVisibility && apiKeyInput) {
      btnToggleApiKeyVisibility.addEventListener('click', () => {
        if (apiKeyInput.type === 'password') {
          apiKeyInput.type = 'text';
          if (eyeIcon) eyeIcon.textContent = 'visibility_off';
        } else {
          apiKeyInput.type = 'password';
          if (eyeIcon) eyeIcon.textContent = 'visibility';
        }
      });
    }

    // Lưu API Key
    if (btnSaveApiKey && apiKeyInput) {
      btnSaveApiKey.addEventListener('click', () => {
        const val = apiKeyInput.value.trim();
        if (!val) {
          showToast('Vui lòng nhập API Key hợp lệ!');
          return;
        }
        setApiKey(val);
        closeApiKeyModal();
        showToast('Đã lưu Google Gemini API Key thành công!');
      });
    }

    // Khôi phục mặc định API Key
    if (btnResetDefaultApiKey && apiKeyInput) {
      btnResetDefaultApiKey.addEventListener('click', () => {
        setApiKey(DEFAULT_GEMINI_API_KEY);
        apiKeyInput.value = DEFAULT_GEMINI_API_KEY;
        showToast('Đã khôi phục khóa API Gemini mặc định của dự án!');
      });
    }

    // 6. Inline CTAs: Xem ảnh lá A3 & Lên lịch tưới
    if (btnViewA3Photo && imagePreviewBox) {
      btnViewA3Photo.addEventListener('click', () => {
        imagePreviewBox.classList.toggle('hidden');
        scrollToBottom();
      });
    }

    if (btnCloseImagePreview && imagePreviewBox) {
      btnCloseImagePreview.addEventListener('click', () => {
        imagePreviewBox.classList.add('hidden');
      });
    }

    if (btnCreateWaterSchedule) {
      btnCreateWaterSchedule.addEventListener('click', () => {
        showToast('Đã thêm lịch tưới 3-4cm cho Lô A3 lúc 16:30 chiều nay vào hệ thống!');
      });
    }

    // 7. Nút xóa đoạn chat
    if (btnClearChat) {
      btnClearChat.addEventListener('click', () => {
        if (confirm('Anh có chắc muốn làm mới toàn bộ cuộc trò chuyện với AgriAI Copilot?')) {
          conversationHistory = [];
          if (chatStream) {
            chatStream.innerHTML = '';
            appendAIMessage(`
### Chào anh Nông! 🌾
Tôi là **AgriAI Copilot** (kết nối trực tiếp **Google Gemini 3.8 Flash**). 
Tôi đã cập nhật dữ liệu sinh trưởng của giống lúa **OM5451** tại **Ruộng A** (42 ngày tuổi, làm đòng). 

Anh cần tư vấn gì về kỹ thuật bón đón đòng, phòng ngừa sâu bệnh hay điều tiết nước hôm nay?
            `);
            showToast('Đã làm mới phiên trò chuyện!');
          }
        }
      });
    }

    // 8. Xuất đoạn chat ra file Markdown
    if (btnExportChat) {
      btnExportChat.addEventListener('click', () => {
        if (!chatStream) return;
        const messages = chatStream.querySelectorAll('.chat-message-enter, > div');
        let exportText = `# NHẬT KÝ HỘI THOẠI NÔNG HỌC AGRI-AI RICESMART\n`;
        exportText += `Thời gian xuất: ${new Date().toLocaleString('vi-VN')}\n`;
        exportText += `Ruộng: ${currentPlotContext.name} (${currentPlotContext.variety} - ${currentPlotContext.stage})\n\n---\n\n`;

        messages.forEach((msg) => {
          const sender = msg.querySelector('strong, .font-semibold')?.textContent?.trim() || 'Tin nhắn';
          const body = msg.querySelector('p, .ai-markdown')?.textContent?.trim() || '';
          if (body) {
            exportText += `### [${sender}]\n${body}\n\n`;
          }
        });

        const blob = new Blob([exportText], { type: 'text/markdown;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `NhatKy_AgriAI_${new Date().toISOString().slice(0, 10)}.md`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast('Đã tải xuống tệp nhật ký tư vấn nông học (.md)!');
      });
    }

    // 9. Nút đổi ruộng
    if (btnSwitchPlot) {
      btnSwitchPlot.addEventListener('click', () => {
        if (currentPlotContext.name === 'Ruộng A') {
          currentPlotContext = {
            name: 'Ruộng B',
            variety: 'ST25',
            season: 'Đông Xuân 2025',
            area: '2.0 ha',
            ageDays: 35,
            stage: 'Đẻ nhánh rộ (chuẩn bị đón đòng)',
            healthAvg: '94/100',
            waterAvg: '4.0 cm',
            ph: '6.5',
            criticalNotes: ['Ruộng B phát triển xanh tốt, cảm biến rầy nâu ghi nhận mật độ thấp an toàn.']
          };
          showToast('Đã chuyển ngữ cảnh sang Ruộng B (Giống ST25, 35 ngày tuổi)');
        } else {
          currentPlotContext = {
            name: 'Ruộng A',
            variety: 'OM5451',
            season: 'Đông Xuân 2025',
            area: '1.2 ha',
            ageDays: 42,
            stage: 'Làm đòng / Phân hóa đòng',
            healthAvg: '88/100',
            waterAvg: '3.1 cm',
            ph: '6.2',
            criticalNotes: [
              'Lô A3: Mực nước hạ thấp còn 1.2 cm, độ ẩm 54%, chớm đốm nâu.',
              'Lô B2: Tích tụ phèn nhẹ ở tầng rễ.'
            ]
          };
          showToast('Đã chuyển ngữ cảnh sang Ruộng A (Giống OM5451, 42 ngày tuổi)');
        }
      });
    }
  });
})();
