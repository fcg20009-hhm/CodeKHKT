/**
 * AgriAI RiceSmart - Bản Đồ Số Hóa & Trực Quan Hóa Ruộng Lúa
 * script.js - Xử lý bản đồ lưới 12 khu vực canh tác, chuyển đổi lớp dữ liệu, phân tích AI và điều khiển tưới tiêu
 */

(function () {
  'use strict';

  // Cơ sở dữ liệu mô phỏng 12 lô ruộng với đầy đủ thông số nông học chi tiết
  const sectorData = {
    A1: {
      title: 'Khu Vực A1',
      score: 94,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '68%',
      water: '3.5 cm',
      temp: '28.5°C',
      ph: '6.2 pH',
      moistureBar: '68%',
      waterBar: '70%',
      tempBar: '60%',
      phBar: '75%',
      aiText:
        'Cây lúa sinh trưởng rất đều, tán lá xanh mướt đồng nhất. Không phát hiện sâu rầy hay dấu hiệu stress nhiệt. Đề xuất giữ nguyên chế độ ngập khô xen kẽ.',
      history: ['94 đ', '91 đ', '93 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    A2: {
      title: 'Khu Vực A2',
      score: 88,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '64%',
      water: '2.8 cm',
      temp: '29.1°C',
      ph: '6.0 pH',
      moistureBar: '64%',
      waterBar: '56%',
      tempBar: '64%',
      phBar: '70%',
      aiText:
        'Mức phát triển đồng đều, chồi đẻ nhánh khỏe. Độ ẩm đất hơi giảm nhẹ so với hôm qua nhưng vẫn nằm trong ngưỡng an toàn.',
      history: ['88 đ', '86 đ', '89 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    A3: {
      title: 'Khu Vực A3',
      score: 61,
      status: 'Cần chú ý',
      statusType: 'warning',
      statusColor: 'amber',
      moisture: '54%',
      water: '1.2 cm',
      temp: '31.5°C',
      ph: '5.8 pH',
      moistureBar: '54%',
      waterBar: '30%',
      tempBar: '82%',
      phBar: '60%',
      aiText:
        'Phát hiện biểu hiện vàng lá ngọn và đốm nâu rải rác trên 12% diện tích Lô A3. Nguyên nhân kết hợp: mực nước rút nhanh dưới 2cm kèm nhiệt độ nắng gắt buổi trưa. Đã phân công kỹ thuật viên kiểm tra.',
      history: ['72 đ', '85 đ', '90 đ'],
      hasBbox: true,
      dronePhoto: 'placeholder',
    },
    A4: {
      title: 'Khu Vực A4',
      score: 90,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '70%',
      water: '3.4 cm',
      temp: '28.2°C',
      ph: '6.4 pH',
      moistureBar: '70%',
      waterBar: '68%',
      tempBar: '58%',
      phBar: '80%',
      aiText:
        'Cây lúa OM5451 sinh trưởng mạnh mẽ, khả năng quang hợp cao. Trạm đo ghi nhận mực nước tự nhiên dồi dào từ nhánh kênh Tây.',
      history: ['90 đ', '90 đ', '87 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    B1: {
      title: 'Khu Vực B1',
      score: 92,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '66%',
      water: '3.1 cm',
      temp: '28.7°C',
      ph: '6.3 pH',
      moistureBar: '66%',
      waterBar: '62%',
      tempBar: '62%',
      phBar: '78%',
      aiText:
        'Độ phì đất cao, mật độ nhánh hữu hiệu đạt 420 chồi/m². Chỉ số NDVI 0.81 khẳng định tán lá xanh sung mãn.',
      history: ['92 đ', '89 đ', '91 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    B2: {
      title: 'Khu Vực B2',
      score: 74,
      status: 'Độ ẩm thấp',
      statusType: 'warning',
      statusColor: 'amber',
      moisture: '56%',
      water: '1.8 cm',
      temp: '30.2°C',
      ph: '5.9 pH',
      moistureBar: '56%',
      waterBar: '40%',
      tempBar: '72%',
      phBar: '65%',
      aiText:
        'Lô B2 nằm ở triền đất cao, độ ẩm đất đang tụt dốc sau 48 giờ không mở van bù. Khuyến nghị mở khóa van số 2 để đưa mực nước lên 3cm.',
      history: ['78 đ', '82 đ', '88 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    B3: {
      title: 'Khu Vực B3',
      score: 96,
      status: 'Rất khỏe',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '72%',
      water: '3.8 cm',
      temp: '27.9°C',
      ph: '6.5 pH',
      moistureBar: '72%',
      waterBar: '76%',
      tempBar: '55%',
      phBar: '85%',
      aiText:
        'Lô có năng suất sinh khối cao nhất toàn cánh đồng. Bộ rễ ăn sâu và chắc chắn, tầng nước bề mặt trong sạch, hoàn toàn không có mầm bệnh rầy nâu.',
      history: ['96 đ', '95 đ', '94 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    B4: {
      title: 'Khu Vực B4',
      score: 89,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '67%',
      water: '3.0 cm',
      temp: '28.8°C',
      ph: '6.1 pH',
      moistureBar: '67%',
      waterBar: '60%',
      tempBar: '63%',
      phBar: '72%',
      aiText:
        'Sinh trưởng ổn định theo đúng lộ trình nông lịch ngày 45. Độ ẩm đất và lượng phân bón đợt 2 đang hấp thụ tốt.',
      history: ['89 đ', '87 đ', '86 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    C1: {
      title: 'Khu Vực C1',
      score: 58,
      status: 'Đốm lá / Bệnh',
      statusType: 'danger',
      statusColor: 'red',
      moisture: '62%',
      water: '2.5 cm',
      temp: '29.8°C',
      ph: '5.6 pH',
      moistureBar: '62%',
      waterBar: '50%',
      tempBar: '70%',
      phBar: '50%',
      aiText:
        'Cảnh báo nguy cấp: Camera Drone phát hiện vết bệnh đạo ôn lá (Pyricularia oryzae) hình mắt én xuất hiện cụm tại góc phía Nam Lô C1. Cần ngưng bón đạm và phun thuốc đặc trị bảo vệ sinh học ngay trong 24 giờ.',
      history: ['65 đ', '76 đ', '84 đ'],
      hasBbox: true,
      dronePhoto: 'placeholder',
    },
    C2: {
      title: 'Khu Vực C2',
      score: 91,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '69%',
      water: '3.3 cm',
      temp: '28.3°C',
      ph: '6.2 pH',
      moistureBar: '69%',
      waterBar: '66%',
      tempBar: '59%',
      phBar: '76%',
      aiText:
        'Duy trì đà phát triển rất chuẩn mực. Bộ rễ trắng và tỏa rộng, chỉ số diệp lục tố SPAD đạt 41.2.',
      history: ['91 đ', '90 đ', '89 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    C3: {
      title: 'Khu Vực C3',
      score: 95,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '71%',
      water: '3.6 cm',
      temp: '27.8°C',
      ph: '6.4 pH',
      moistureBar: '71%',
      waterBar: '72%',
      tempBar: '54%',
      phBar: '82%',
      aiText:
        'Đạt chuẩn xuất sắc. Mực nước dẫn ổn định qua van tự động, màu sắc lá sáng bóng và đẻ nhánh đều đặn.',
      history: ['95 đ', '94 đ', '92 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
    C4: {
      title: 'Khu Vực C4',
      score: 87,
      status: 'Tối ưu',
      statusType: 'optimal',
      statusColor: 'emerald',
      moisture: '63%',
      water: '2.9 cm',
      temp: '29.4°C',
      ph: '6.0 pH',
      moistureBar: '63%',
      waterBar: '58%',
      tempBar: '68%',
      phBar: '70%',
      aiText:
        'Lô giáp bờ bao phía đông, cây lúa cứng cáp, ít chịu ảnh hưởng của sâu cuốn lá. Mọi chỉ số đất nước đều trong ngưỡng an toàn.',
      history: ['87 đ', '88 đ', '85 đ'],
      hasBbox: false,
      dronePhoto: 'placeholder',
    },
  };

  let currentSelectedSector = 'A3';
  let latestLiveSensorData = null;
  let sensorIsConnected = false;

  function applyLiveSensorReadings() {
    if (currentSelectedSector !== 'A3') return;

    const metricMoisture = document.getElementById('metric-moisture');
    const metricTemp = document.getElementById('metric-temp');
    const metricPh = document.getElementById('metric-ph');
    const barMoisture = document.getElementById('bar-moisture');
    const barTemp = document.getElementById('bar-temp');
    const barPh = document.getElementById('bar-ph');
    const updated = document.getElementById('sector-updated');
    const humidity = latestLiveSensorData && latestLiveSensorData.humidity;
    const temperature = latestLiveSensorData && latestLiveSensorData.temperature;
    const ph = latestLiveSensorData && latestLiveSensorData.ph;

    if (metricMoisture) metricMoisture.textContent = Number.isFinite(humidity) ? `${humidity}%` : '--';
    if (metricTemp) metricTemp.textContent = Number.isFinite(temperature) ? `${temperature.toFixed(1)}°C` : '--';
    if (metricPh) metricPh.textContent = Number.isFinite(ph) ? `${ph.toFixed(2)} pH` : '--';
    if (barMoisture) barMoisture.style.width = Number.isFinite(humidity) ? `${Math.max(0, Math.min(humidity, 100))}%` : '0%';
    if (barTemp) barTemp.style.width = Number.isFinite(temperature) ? `${Math.max(0, Math.min(temperature / 40 * 100, 100))}%` : '0%';
    if (barPh) barPh.style.width = Number.isFinite(ph) ? `${Math.max(0, Math.min(ph / 14 * 100, 100))}%` : '0%';
    if (updated) {
      updated.textContent = sensorIsConnected
        ? `ESP32-S3 • ${new Date(latestLiveSensorData.updatedAt).toLocaleTimeString()}`
        : 'Đang chờ kết nối ESP32-S3';
    }
  }

  async function refreshLiveSensorReadings() {
    try {
      const statusResponse = await fetch('http://localhost:3000/api/sensor/status', { cache: 'no-store' });
      if (!statusResponse.ok) {
        throw new Error(`Sensor status request failed with HTTP ${statusResponse.status}`);
      }
      const status = await statusResponse.json();
      sensorIsConnected = status.connected === true;

      if (!sensorIsConnected) {
        latestLiveSensorData = null;
        applyLiveSensorReadings();
        return;
      }

      const sensorResponse = await fetch('http://localhost:3000/api/sensor', { cache: 'no-store' });
      if (!sensorResponse.ok) {
        throw new Error(`Sensor data request failed with HTTP ${sensorResponse.status}`);
      }
      latestLiveSensorData = await sensorResponse.json();
      applyLiveSensorReadings();
    } catch (error) {
      console.error('Unable to refresh ESP32 sensor readings:', error);
      sensorIsConnected = false;
      latestLiveSensorData = null;
      applyLiveSensorReadings();
    }
  }

  /**
   * Chọn lô ruộng hiển thị chi tiết lên panel bên phải
   * @param {string} sectorCode
   */
  function selectSector(sectorCode) {
    const data = sectorData[sectorCode];
    if (!data) return;

    currentSelectedSector = sectorCode;

    // Reset styles cho tất cả các sector card
    document.querySelectorAll('.sector-card').forEach((card) => {
      card.classList.remove(
        'scale-[1.02]',
        'shadow-md',
        'bg-amber-50',
        'bg-red-50',
        'bg-emerald-50'
      );
      const badge = card.querySelector('.selected-indicator');
      if (badge) badge.remove();
    });

    // Định kiểu cho thẻ được chọn
    const targetCard = document.getElementById(`cell-${sectorCode}`);
    if (targetCard) {
      targetCard.classList.add('scale-[1.02]', 'shadow-md');
      if (data.statusType === 'danger') {
        targetCard.classList.add('bg-red-50');
      } else if (data.statusType === 'warning') {
        targetCard.classList.add('bg-amber-50');
      } else {
        targetCard.classList.add('bg-emerald-50');
      }
    }

    // Cập nhật thông tin chi tiết
    const detailTitle = document.getElementById('detail-title');
    const detailScore = document.getElementById('detail-score');
    const detailStatusText = document.getElementById('detail-status-text');
    const btnIrrigateText = document.getElementById('btn-irrigate-text');

    if (detailTitle) detailTitle.innerText = data.title;
    if (detailScore) detailScore.innerText = `${data.score}/100`;
    if (detailStatusText) detailStatusText.innerText = data.status;
    if (btnIrrigateText)
      btnIrrigateText.innerText = `Gửi lệnh tưới bù nước cho ${sectorCode}`;

    // Kiểu dáng badge trạng thái
    const pill = document.getElementById('detail-status-pill');
    const iconWrap = document.getElementById('detail-icon-wrap');
    const icon = document.getElementById('detail-icon');

    if (pill && iconWrap && icon && detailScore) {
      if (data.statusType === 'danger') {
        pill.className =
          'px-2.5 py-0.5 rounded-full font-label-md text-label-md bg-red-100 text-red-900 font-semibold flex items-center gap-1.5';
        iconWrap.className =
          'w-12 h-12 rounded-2xl bg-red-100 flex items-center justify-center text-red-800';
        icon.innerText = 'pest_control';
        detailScore.className = 'text-red-700 font-bold';
      } else if (data.statusType === 'warning') {
        pill.className =
          'px-2.5 py-0.5 rounded-full font-label-md text-label-md bg-amber-100 text-amber-900 font-semibold flex items-center gap-1.5';
        iconWrap.className =
          'w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-800';
        icon.innerText = 'warning';
        detailScore.className = 'text-amber-800 font-bold';
      } else {
        pill.className =
          'px-2.5 py-0.5 rounded-full font-label-md text-label-md bg-emerald-100 text-emerald-900 font-semibold flex items-center gap-1.5';
        iconWrap.className =
          'w-12 h-12 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-800';
        icon.innerText = 'spa';
        detailScore.className = 'text-[#1b5e20] font-bold';
      }
    }

    // Cập nhật các chỉ số cảm biến
    const metricMoisture = document.getElementById('metric-moisture');
    const metricWater = document.getElementById('metric-water');
    const metricTemp = document.getElementById('metric-temp');
    const metricPh = document.getElementById('metric-ph');

    if (metricMoisture) metricMoisture.innerText = data.moisture;
    if (metricWater) metricWater.innerText = data.water;
    if (metricTemp) metricTemp.innerText = data.temp;
    if (metricPh) metricPh.innerText = data.ph;

    const barMoisture = document.getElementById('bar-moisture');
    const barWater = document.getElementById('bar-water');
    const barTemp = document.getElementById('bar-temp');
    const barPh = document.getElementById('bar-ph');

    if (barMoisture) barMoisture.style.width = data.moistureBar;
    if (barWater) barWater.style.width = data.waterBar;
    if (barTemp) barTemp.style.width = data.tempBar;
    if (barPh) barPh.style.width = data.phBar;

    // Chuẩn đoán AI
    const detailAiText = document.getElementById('detail-ai-text');
    if (detailAiText) detailAiText.innerText = data.aiText;

    // Lịch sử điểm
    const hist1 = document.getElementById('hist-1');
    const hist2 = document.getElementById('hist-2');
    const hist3 = document.getElementById('hist-3');

    if (hist1 && data.history[0]) hist1.innerText = data.history[0];
    if (hist2 && data.history[1]) hist2.innerText = data.history[1];
    if (hist3 && data.history[2]) hist3.innerText = data.history[2];

    // Khung nhận diện Bounding Box AI
    const bbox = document.getElementById('detail-bbox');
    if (bbox) {
      bbox.style.display = data.hasBbox ? 'flex' : 'none';
    }

    const sectorUpdated = document.getElementById('sector-updated');
    if (sectorUpdated) sectorUpdated.innerText = 'Vừa cập nhật';

    applyLiveSensorReadings();
  }

  /**
   * Hiển thị thông báo Toast
   * @param {string} title
   * @param {string} desc
   */
  function showToast(title, desc) {
    const toast = document.getElementById('toast-notification');
    const toastTitle = document.getElementById('toast-title');
    const toastDesc = document.getElementById('toast-desc');

    if (!toast || !toastTitle || !toastDesc) return;

    toastTitle.innerText = title;
    toastDesc.innerText = desc;

    toast.classList.remove('translate-y-20', 'opacity-0');
    toast.classList.add('translate-y-0', 'opacity-100');

    setTimeout(() => {
      toast.classList.remove('translate-y-0', 'opacity-100');
      toast.classList.add('translate-y-20', 'opacity-0');
    }, 3800);
  }

  // Kích hoạt van tưới nước
  function triggerIrrigation() {
    showToast(
      `Đã kích hoạt van xả nước ${currentSelectedSector}`,
      `Lệnh mở van điện từ 35% lưu lượng nước ngọt cho ${currentSelectedSector} đã được xác nhận.`
    );
  }

  // Lên lịch khảo sát đặc biệt
  function scheduleSpecialCheck() {
    showToast(
      'Đã tạo lịch kiểm tra chuyên sâu',
      `Chuyên viên kiểm định nông nghiệp sẽ khảo sát thực địa ${currentSelectedSector} vào sáng mai 08:00.`
    );
  }

  // Chuyển đổi tần số cảm biến thời gian thực
  function toggleRealtimeSensor() {
    showToast(
      'Cảm biến tần số cao đang phát sóng',
      `Dữ liệu cảm biến đất và tán lá tại ${currentSelectedSector} đang truyền tải chu kỳ 5 giây/lần.`
    );
  }

  /**
   * Chuyển đổi lớp bản đồ (Sức khỏe, Nước, Sâu bệnh, Nhiệt độ)
   * @param {string} layerType
   * @param {HTMLElement} buttonElement
   */
  function switchLayer(layerType, buttonElement) {
    // Reset style các nút layer
    document.querySelectorAll('.layer-pill').forEach((btn) => {
      btn.classList.remove('bg-primary', 'text-on-primary', 'active-layer');
      btn.classList.add('bg-surface-container-low', 'text-on-surface-variant');
    });

    // Kích hoạt nút được chọn
    if (buttonElement) {
      buttonElement.classList.add('bg-primary', 'text-on-primary', 'active-layer');
      buttonElement.classList.remove('bg-surface-container-low', 'text-on-surface-variant');
    }

    // Cập nhật số liệu trên từng ô lưới
    document.querySelectorAll('.sector-card').forEach((card) => {
      const code = card.id.replace('cell-', '');
      const item = sectorData[code];
      if (!item) return;

      const metricEl = card.querySelector('.font-numeric-metric');
      if (!metricEl) return;

      if (layerType === 'water') {
        metricEl.innerText = item.water;
      } else if (layerType === 'temp') {
        metricEl.innerText = item.temp;
      } else if (layerType === 'health' || layerType === 'all') {
        metricEl.innerText = item.score;
      } else if (layerType === 'pest') {
        metricEl.innerText =
          item.statusType === 'danger'
            ? 'Bệnh'
            : item.statusType === 'warning'
            ? 'Theo dõi'
            : 'An toàn';
      }
    });

    const labelName = buttonElement ? buttonElement.innerText.trim() : layerType;
    showToast(
      `Đã kích hoạt lớp: ${labelName}`,
      'Bản đồ lưới đang hiển thị dữ liệu tập trung theo bộ lọc được chọn.'
    );
  }

  // Xuất ra window để tương thích toàn diện
  window.selectSector = selectSector;
  window.switchLayer = switchLayer;
  window.triggerIrrigation = triggerIrrigation;
  window.scheduleSpecialCheck = scheduleSpecialCheck;
  window.toggleRealtimeSensor = toggleRealtimeSensor;

  // Khởi tạo các sự kiện khi DOM tải xong
  document.addEventListener('DOMContentLoaded', () => {
    // 1. Gắn sự kiện click cho các ô sector card
    document.querySelectorAll('.sector-card').forEach((card) => {
      card.addEventListener('click', function () {
        const code = this.id.replace('cell-', '');
        if (code) selectSector(code);
      });
    });

    // 2. Gắn sự kiện cho các nút layer pill
    document.querySelectorAll('.layer-pill').forEach((btn) => {
      btn.addEventListener('click', function () {
        const layer = this.getAttribute('data-layer');
        if (layer) switchLayer(layer, this);
      });
    });

    // 3. Nút kích hoạt tưới
    const btnIrrigate = document.getElementById('btn-trigger-irrigation');
    if (btnIrrigate) {
      btnIrrigate.addEventListener('click', triggerIrrigation);
    }

    // 4. Nút lên lịch kiểm tra
    const btnSchedule = document.getElementById('btn-schedule-check');
    if (btnSchedule) {
      btnSchedule.addEventListener('click', scheduleSpecialCheck);
    }

    // 5. Nút cảm biến realtime
    const btnSensor = document.getElementById('btn-toggle-sensor');
    if (btnSensor) {
      btnSensor.addEventListener('click', toggleRealtimeSensor);
    }

    // 6. Nút đồng bộ trạm IoT
    const refreshBtn = document.getElementById('refresh-grid-btn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function () {
        const icon = this.querySelector('.material-symbols-outlined');
        if (icon) icon.classList.add('animate-spin');
        setTimeout(() => {
          if (icon) icon.classList.remove('animate-spin');
          showToast(
            'Đã đồng bộ 12 trạm quan trắc',
            'Tất cả cảm biến và camera vệ tinh đã làm mới dữ liệu chu kỳ 10 phút.'
          );
        }, 900);
      });
    }

    // Khởi tạo mặc định chọn lô A3
    selectSector('A3');
    refreshLiveSensorReadings();
    setInterval(refreshLiveSensorReadings, 1000);
  });
})();
