---
name: AgriAI RiceSmart Precision Agronomy
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#41493e'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#717a6d'
  outline-variant: '#c0c9bb'
  surface-tint: '#2a6b2c'
  primary: '#00450d'
  on-primary: '#ffffff'
  primary-container: '#1b5e20'
  on-primary-container: '#90d689'
  inverse-primary: '#91d78a'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#274200'
  on-tertiary: '#ffffff'
  tertiary-container: '#375b00'
  on-tertiary-container: '#90d927'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#acf4a4'
  primary-fixed-dim: '#91d78a'
  on-primary-fixed: '#002203'
  on-primary-fixed-variant: '#0c5216'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#acf847'
  tertiary-fixed-dim: '#91db2a'
  on-tertiary-fixed: '#102000'
  on-tertiary-fixed-variant: '#304f00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.015em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  numeric-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  telemetry-code:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 2rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system establishes an intelligent, field-tested, and scientifically grounded interface for precision paddy agriculture powered by AI. It bridges high-density agronomic data—soil hydrology, spectral crop health indices (NDVI/EVI), automated sluice gates, and drone telemetry—with immediate operational clarity for agronomists, farm operators, and agricultural engineers.

The aesthetic fuses modern high-tech enterprise tooling with organic agricultural depth: crisp, structural typography, deliberate data density, atmospheric ambient layering, and focused tactical accents. Rather than appearing purely industrial or overly conceptual, the interface evokes calm confidence, high reliability, and deep biological attunement. It balances outdoor readability under bright sunlight with nuanced analytical hierarchy in the control room.

## Colors

The palette grounds high-tech agronomy in rich natural foliage tones paired with diagnostic utility colors:

- **Primary (`#1B5E20`, `#2E7D32`)**: Dense Forest Green represents foundational vitality, ecosystem stability, and primary navigation/action anchors.
- **Secondary (`#059669`, `#10B981`)**: Emerald Green serves as an operational health indicator, signaling optimal photosynthesis, thriving crop stages, and verified AI predictions.
- **Tertiary / Accent (`#84CC16`)**: Vibrant Lime Green acts as a tactical beacon for active live telemetry streams, automated irrigation pulses, and real-time field sensors.
- **Telemetry & Status Roles**:
  - **Warning Amber/Orange (`#F59E0B`, `#EA580C`)**: Hydric stress, nitrogen deficiency warnings, weather disruptions, and pest risk thresholds.
  - **Danger Crimson (`#EF4444`)**: Critical sluice failure, bacterial leaf blight detection, sensor offline, or rapid flood warnings.
  - **Info Sky/Cyan (`#0284C7`, `#06B6D4`)**: Water table metrics, irrigation channel flow rates, atmospheric humidity, and drone flight paths.
- **Surfaces & Neutrals**: Base canvas employs a soft, glare-reducing atmospheric gray (`#F8FAFC`, `#F1F5F9`), overlaid with crisp clean white surfaces (`#FFFFFF`) framed by precise slate borders (`#E2E8F0`, `#CBD5E1`) to guarantee high-contrast legibility in varying lighting conditions.

## Typography

The typographic hierarchy combines structural clarity with humanized geometry. Plus Jakarta Sans handles primary wayfinding, section headings, and large sensor telemetry readouts—providing distinct geometric apertures that remain legible across harsh ambient conditions. Inter handles tabular data grids, diagnostic body prose, micro-labels, and input fields with systematic neutral precision.

Numbers are critical: telemetry indicators (soil moisture %, water depth in cm, N-P-K concentration, NDVI floats) utilize proportional numeric alignment with tight letter spacing for rapid scanning across dashboard panels.

## Layout & Spacing

The system runs on an 8pt spatial grid built around dense agronomic telemetry and geospatial map rendering:

- **Desktop (>= 1280px)**: 12-column fluid grid with `2rem` gutters and `3rem` margins. Supports multi-pane mission control: split-view GIS zoning maps, real-time sensor streams, and AI anomaly alerts.
- **Tablet / In-Cab Terminals (768px - 1279px)**: 8-column layout with `1.5rem` gutters and `2rem` margins, collapsing tertiary analytical panels into contextual drawers.
- **Mobile Handheld (Field Inspection) (< 768px)**: 4-column layout with `1rem` gutters and `1rem` margins, optimized for single-thumb navigation, field photo uploads, and rapid valve actuators.

Component density balances dense data tables with generous touch targets (minimum 44x44px) to support wet or gloved handling in the field.

## Elevation & Depth

Visual hierarchy leverages a hybrid approach of subtle tonal layering, gossamer slate borders, and soft botanical-tinted ambient shadows:

1. **Surface 0 (Field Canvas)**: `#F8FAFC` base slate-tinted canvas for minimal glare.
2. **Surface 1 (Card & Module Foundation)**: `#FFFFFF` with a hairline 1px border (`#E2E8F0`) and an ambient shadow `0 1px 3px rgba(15, 23, 42, 0.04), 0 1px 2px rgba(15, 23, 42, 0.02)`.
3. **Surface 2 (Elevated Field Panels & Smart Trays)**: Elevated white cards featuring `0 4px 6px -1px rgba(27, 94, 32, 0.04), 0 2px 4px -2px rgba(15, 23, 42, 0.05)` combined with border `#E2E8F0`.
4. **Surface 3 (Flyouts, Actuator Modals, AI Diagnostic Sheets)**: `0 12px 24px -4px rgba(15, 23, 42, 0.08), 0 4px 8px -2px rgba(27, 94, 32, 0.03)` with border `#CBD5E1`.
5. **Glassmorphic Map Overlays**: On live satellite/GIS views, control chips and drone telemetry widgets use `rgba(255, 255, 255, 0.88)` with a 12px backdrop blur and 1px `#E2E8F0` border, ensuring continuous spatial context beneath controls.

## Shapes

A balanced `0.5rem` (`8px`) base radius defines standard inputs and buttons, while container cards and telemetry modules use `1rem` (`16px`) to produce approachable, ergonomic instruments. 

Status badges, sensor pill nodes, and AI mode indicators transition to full pill curves (`9999px`) to immediately distinguish active states from structural data frames. Map polygons and paddy plot boundaries retain crisp, unrounded geospatial edges to ensure physical surveying fidelity.

## Components

### Buttons & Actuators
- **Primary Action (Valve trigger, AI scan trigger)**: Solid Forest Green `#1B5E20`, hover `#2E7D32`, text white, `10px` vertical by `18px` horizontal padding, `8px` corner radius. Soft forest ambient glow on focus.
- **Secondary (Data export, parameter filter)**: White background, 1px `#CBD5E1` border, text `#1E293B`, hover `#F1F5F9`.
- **Destructive/Emergency (Cut off main canal, abort cycle)**: Crimson `#EF4444`, hover `#DC2626`, text white.

### Agronomic Telemetry Cards
- Encased in white `#FFFFFF`, bordered by 1px `#E2E8F0`, with `16px` border-radius and `20px` internal padding.
- Metric display pairs a small uppercase `label-sm` title (e.g., "WATER DEPTH — SECTOR A4"), large `numeric-metric` readout ("4.8 cm"), and an inline trend badge (`+0.4 cm/h`, Emerald or Amber).
- Includes micro-sparklines or hydrological gauges rendered in Sky Cyan (`#0284C7`) or Emerald (`#10B981`).

### Status Badges & Chips
- Fully rounded pills (`9999px`), `4px 10px` padding.
- **Optimal / Healthy**: Background `#ECFDF5`, text `#065F46`, emerald dot indicator.
- **Attention / Stress**: Background `#FEF3C7`, text `#92400E`, amber dot indicator.
- **Pest / Critical Outbreak**: Background `#FEE2E2`, text `#991B1B`, crimson pulsing dot.
- **AI Recommendation**: Background `#F0FDF4`, border 1px `#BBF7D0`, text `#166534`, leading sparkle icon.

### Form Inputs & Sensor Controls
- Text inputs and dropdowns use clean `#FFFFFF` fill, 1px `#CBD5E1` border, `8px` corner radius, and `14px` typography. Focused state applies a dual-ring: 1px `#1B5E20` with a 3px outer ring at `rgba(27, 94, 32, 0.15)`.
- Steppers for sluice gate levels and target pH thresholds feature tactile raised buttons (+ / -) with audible tactile feedback styling.

### Selection Controls
- Checkboxes and radio buttons use `#1B5E20` active state with pure white icons. Unchecked borders use `#94A3B8`. Touch target size remains padded to at least 40px for reliable field interaction.

### Field Map & AI Vision HUD
- Overlaid flight controls and NDVI color spectrum ramps utilize frosted white glass panels (`rgba(255, 255, 255, 0.9)`), clean dividers, and high-contrast dark text (`#0F172A`) for instant reading against saturated green crop imagery.