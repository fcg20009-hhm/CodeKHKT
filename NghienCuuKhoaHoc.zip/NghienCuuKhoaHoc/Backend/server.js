const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const port = Number(process.env.PORT) || 3000;
const connectionTimeoutMs = 10_000;
const projectRoot = path.resolve(__dirname, '..');

const requiredSensorFields = [
  'light_adc',
  'light_voltage',
  'tds_adc',
  'tds_voltage',
  'ph_adc',
  'ph_voltage',
  'ph',
  'gas_adc',
  'gas_voltage',
];
const optionalSensorFields = ['temperature', 'humidity'];

let latestSensorData = null;
let latestUpdatedAt = null;

app.use(cors());
app.use(express.json({ limit: '10kb' }));

app.post('/api/sensor', (req, res) => {
  const payload = req.body;
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return res.status(400).json({ error: 'Sensor data must be a JSON object.' });
  }

  const fields = [...requiredSensorFields, ...optionalSensorFields];
  const invalidField = fields.find(
    (field) =>
      Object.prototype.hasOwnProperty.call(payload, field) &&
      (typeof payload[field] !== 'number' || !Number.isFinite(payload[field]))
  );
  const missingField = requiredSensorFields.find(
    (field) => !Object.prototype.hasOwnProperty.call(payload, field)
  );

  if (missingField || invalidField) {
    return res.status(400).json({
      error: missingField
        ? `Missing required sensor field: ${missingField}`
        : `Sensor field must be a finite number: ${invalidField}`,
    });
  }

  latestSensorData = Object.fromEntries(
    fields
      .filter((field) => Object.prototype.hasOwnProperty.call(payload, field))
      .map((field) => [field, payload[field]])
  );
  latestUpdatedAt = new Date().toISOString();

  return res.json({ ok: true, updatedAt: latestUpdatedAt });
});

app.get('/api/sensor', (req, res) => {
  if (!latestSensorData) {
    return res.status(404).json({ error: 'No sensor data has been received yet.' });
  }

  return res.json({ ...latestSensorData, updatedAt: latestUpdatedAt });
});

app.get('/api/sensor/status', (req, res) => {
  const connected =
    latestUpdatedAt !== null &&
    Date.now() - Date.parse(latestUpdatedAt) <= connectionTimeoutMs;

  return res.json({ connected, updatedAt: latestUpdatedAt });
});

app.get('*', (req, res, next) => {
  if (path.extname(req.path) || req.path === '/') {
    return next();
  }

  const htmlPath = path.resolve(projectRoot, `.${req.path}.html`);
  if (!htmlPath.startsWith(`${projectRoot}${path.sep}`)) {
    return next();
  }

  if (fs.existsSync(htmlPath)) {
    return res.redirect(302, `${req.path}.html`);
  }

  return next();
});

app.use(express.static(projectRoot));

app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && error.status === 400 && 'body' in error) {
    return res.status(400).json({ error: 'Request body contains invalid JSON.' });
  }

  return next(error);
});

app.listen(port, () => {
  console.log(`Website and sensor API listening on http://localhost:${port}`);
});
