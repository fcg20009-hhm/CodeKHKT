/**
 * AgriAI RiceSmart - Tình Trạng Ruộng Lúa (Field Condition & Agronomic Cockpit)
 * JavaScript Application Logic (script.js)
 */

document.addEventListener("DOMContentLoaded", () => {
  // ==========================================
  // 1. MOCK DATA STORE (Cơ sở dữ liệu thực địa)
  // ==========================================
  const FIELD_DATA = {
    A: {
      id: "A",
      name: "Ruộng A (Cánh đồng Thới Lai - Cần Thơ)",
      variety: "OM5451 (Vụ Đông Xuân 2025)",
      area: "4.2 ha",
      sowingDate: "28/11/2024",
      ageDays: 38,
      stage: "Đẻ nhánh rộ (Giai đoạn II)",
      nextStage: "Làm đòng (sau 12 ngày)",
      gdd: "840 °C-ngày",
      healthIndex: 91,
      healthStatus: "Sinh trưởng tối ưu",
      waterLevel: "4.5 cm",
      waterStatus: "AWD Chu kỳ ngập nông",
      waterBarPct: 65,
      soilMoisture: "82%",
      soilPh: "6.2",
      soilPhStatus: "Tối ưu đất phù sa ngọt",
      soilEc: "0.85 mS/cm",
      pestRisk: "14%",
      pestRiskStatus: "Nguy cơ thấp (Có khoanh vùng)",
      sectors: [
        {
          id: "A1",
          name: "Lô A1 - Khu mẫu chuẩn",
          area: "1.1 ha",
          healthScore: 96,
          status: "optimal",
          statusText: "Tối ưu",
          badgeColor: "bg-emerald-100 text-emerald-800",
          water: "4.2 cm",
          soilPh: "6.3",
          chlorophyll: "LCC Cấp 4 (Đạt)",
          density: "220 dảnh/m²",
          pestRate: "An toàn (0.5 con/bụi)",
          note: "Lá đứng, màu xanh tranh đồng đều, rễ chùm phát triển sâu 14cm."
        },
        {
          id: "A2",
          name: "Lô A2 - Cạnh Kênh Chính",
          area: "0.9 ha",
          healthScore: 88,
          status: "warning",
          statusText: "Mực nước cao",
          badgeColor: "bg-amber-100 text-amber-800",
          water: "6.8 cm",
          soilPh: "6.1",
          chlorophyll: "LCC Cấp 4",
          density: "205 dảnh/m²",
          pestRate: "Chớm ốc bươu cắn lá non",
          note: "Nước từ cống Kênh Đông dâng cao hơn ngưỡng AWD khuyến nghị 2cm. Cần hé van xả đáy."
        },
        {
          id: "A3",
          name: "Lô A3 - Vùng đốm nâu nghi vấn",
          area: "1.2 ha",
          healthScore: 78,
          status: "danger",
          statusText: "Cần can thiệp",
          badgeColor: "bg-red-100 text-red-800",
          water: "3.5 cm",
          soilPh: "5.8",
          chlorophyll: "LCC Cấp 3 (Vàng chóp lá)",
          density: "195 dảnh/m²",
          pestRate: "Đốm nâu (Bipolaris) 8%",
          note: "Đất có dấu hiệu yếm khí nhẹ, phát hiện vết đốm nâu rải rác. Đã khuyến nghị bón bổ sung Silic + phơi ruộng nứt chân chim."
        },
        {
          id: "A4",
          name: "Lô A4 - Khu hữu cơ vi sinh",
          area: "1.0 ha",
          healthScore: 93,
          status: "optimal",
          statusText: "Phát triển tốt",
          badgeColor: "bg-emerald-100 text-emerald-800",
          water: "4.6 cm",
          soilPh: "6.4",
          chlorophyll: "LCC Cấp 4",
          density: "215 dảnh/m²",
          pestRate: "Thiên địch nhện lycosa cao",
          note: "Mật độ thiên địch tốt, đất tơi xốp nhiều trùn chỉ, cây cứng cáp."
        }
      ],
      waterHistory: [
        { day: "T2 (30/1)", val: 5.0, status: "Ngập" },
        { day: "T3 (31/1)", val: 4.8, status: "Ngập" },
        { day: "T4 (01/2)", val: 4.2, status: "Ngập vừa" },
        { day: "T5 (02/2)", val: 3.1, status: "Khô dần" },
        { day: "T6 (03/2)", val: 1.5, status: "Khô nứt nhẹ" },
        { day: "T7 (04/2)", val: 4.5, status: "Tưới bổ sung" },
        { day: "CN (Hôm nay)", val: 4.5, status: "Ngập tiêu chuẩn" }
      ],
      nutrients: {
        n: { label: "Đạm (N)", level: 82, text: "Đầy đủ", color: "bg-emerald-500" },
        p: { label: "Lân hữu dụng (P₂O₅)", level: 75, text: "Khá", color: "bg-emerald-500" },
        k: { label: "Kali trao đổi (K₂O)", level: 88, text: "Tốt", color: "bg-emerald-500" },
        zn: { label: "Kẽm vi lượng (Zn)", level: 62, text: "Cần bổ sung dặm", color: "bg-amber-500" },
        si: { label: "Silic hữu hiệu (SiO₂)", level: 68, text: "Trung bình", color: "bg-amber-500" }
      }
    },
    B: {
      id: "B",
      name: "Ruộng B (Cánh đồng Cờ Đỏ - Cần Thơ)",
      variety: "ST25 Đặc sản (Vụ Đông Xuân 2025)",
      area: "6.8 ha",
      sowingDate: "20/11/2024",
      ageDays: 46,
      stage: "Cuối đẻ nhánh - Chuẩn bị đón đòng",
      nextStage: "Phân hóa đòng (sau 4 ngày)",
      gdd: "990 °C-ngày",
      healthIndex: 86,
      healthStatus: "Sinh trưởng khá",
      waterLevel: "3.8 cm",
      waterStatus: "AWD Chu kỳ cạn chân",
      waterBarPct: 54,
      soilMoisture: "76%",
      soilPh: "5.9",
      soilPhStatus: "Hơi chua nhẹ (Đất phù sa bồi)",
      soilEc: "0.92 mS/cm",
      pestRisk: "22%",
      pestRiskStatus: "Cảnh báo đạo ôn lá",
      sectors: [
        {
          id: "B1",
          name: "Lô B1 - Khu trung tâm",
          area: "2.2 ha",
          healthScore: 90,
          status: "optimal",
          statusText: "Khỏe mạnh",
          badgeColor: "bg-emerald-100 text-emerald-800",
          water: "4.0 cm",
          soilPh: "6.0",
          chlorophyll: "LCC Cấp 4",
          density: "230 dảnh/m²",
          pestRate: "An toàn",
          note: "Thân cứng, bộ rễ ăn sâu, không ghi nhận vết bệnh đạo ôn."
        },
        {
          id: "B2",
          name: "Lô B2 - Gần lũy tre chắn gió",
          area: "1.8 ha",
          healthScore: 74,
          status: "danger",
          statusText: "Chớm Đạo ôn",
          badgeColor: "bg-red-100 text-red-800",
          water: "4.5 cm",
          soilPh: "5.7",
          chlorophyll: "LCC Cấp 4.5 (Hơi thừa đạm)",
          density: "245 dảnh/m²",
          pestRate: "Vết chấm mắt én 12%",
          note: "Tán rậm rạp, sương mù đọng lâu sáng sớm dẫn đến nảy mầm nấm Magnaporthe oryzae. Cần ngưng bón đạm, phun Tricyclazole."
        },
        {
          id: "B3",
          name: "Lô B3 - Vùng gò cao",
          area: "1.5 ha",
          healthScore: 89,
          status: "optimal",
          statusText: "Ổn định",
          badgeColor: "bg-emerald-100 text-emerald-800",
          water: "3.2 cm",
          soilPh: "6.1",
          chlorophyll: "LCC Cấp 4",
          density: "210 dảnh/m²",
          pestRate: "Thấp",
          note: "Thoát nước nhanh, tầng rễ thông thoáng."
        },
        {
          id: "B4",
          name: "Lô B4 - Vùng trũng trút nước",
          area: "1.3 ha",
          healthScore: 82,
          status: "warning",
          statusText: "Đọng nước cục bộ",
          badgeColor: "bg-amber-100 text-amber-800",
          water: "5.8 cm",
          soilPh: "5.8",
          chlorophyll: "LCC Cấp 3.5",
          density: "200 dảnh/m²",
          pestRate: "Có rầy nâu nhẹ",
          note: "Đáy trũng khó thoát nước, cần khơi rãnh phụ thoát bớt nước sang mương bao."
        }
      ],
      waterHistory: [
        { day: "T2", val: 5.5, status: "Ngập" },
        { day: "T3", val: 5.0, status: "Ngập" },
        { day: "T4", val: 4.5, status: "Vừa" },
        { day: "T5", val: 4.0, status: "Hạ" },
        { day: "T6", val: 3.5, status: "AWD cạn" },
        { day: "T7", val: 3.8, status: "AWD cạn" },
        { day: "CN", val: 3.8, status: "Giữ mực chuẩn" }
      ],
      nutrients: {
        n: { label: "Đạm (N)", level: 91, text: "Thừa nhẹ (Cần hãm)", color: "bg-amber-500" },
        p: { label: "Lân hữu dụng (P₂O₅)", level: 80, text: "Đạt", color: "bg-emerald-500" },
        k: { label: "Kali trao đổi (K₂O)", level: 72, text: "Cần tăng đợt đón đòng", color: "bg-amber-500" },
        zn: { label: "Kẽm vi lượng (Zn)", level: 85, text: "Đạt", color: "bg-emerald-500" },
        si: { label: "Silic hữu hiệu (SiO₂)", level: 64, text: "Khá thấp", color: "bg-red-500" }
      }
    },
    C: {
      id: "C",
      name: "Ruộng C (HTX Nông nghiệp Vĩnh Thạnh)",
      variety: "Đài Thơm 8 (Vụ Đông Xuân 2025)",
      area: "3.5 ha",
      sowingDate: "05/12/2024",
      ageDays: 31,
      stage: "Bắt đầu đẻ nhánh (Giai đoạn I)",
      nextStage: "Đẻ nhánh rộ (sau 7 ngày)",
      gdd: "690 °C-ngày",
      healthIndex: 94,
      healthStatus: "Sinh trưởng rất khỏe",
      waterLevel: "5.0 cm",
      waterStatus: "Ngập nông giữ ẩm",
      waterBarPct: 71,
      soilMoisture: "85%",
      soilPh: "6.5",
      soilPhStatus: "Rất tốt (Đất thịt pha phù sa)",
      soilEc: "0.78 mS/cm",
      pestRisk: "8%",
      pestRiskStatus: "Rất an toàn",
      sectors: [
        {
          id: "C1",
          name: "Lô C1 - Khu thử nghiệm sạ cụm",
          area: "1.2 ha",
          healthScore: 97,
          status: "optimal",
          statusText: "Tối ưu",
          badgeColor: "bg-emerald-100 text-emerald-800",
          water: "5.0 cm",
          soilPh: "6.5",
          chlorophyll: "LCC Cấp 4",
          density: "210 dảnh/m²",
          pestRate: "0%",
          note: "Mô hình sạ cụm bằng máy giúp mạ phân bố đều, ít sâu bệnh, quang hợp tối đa."
        },
        {
          id: "C2",
          name: "Lô C2 - Khu đối chứng sạ lan",
          area: "1.3 ha",
          healthScore: 91,
          status: "optimal",
          statusText: "Bình thường",
          badgeColor: "bg-emerald-100 text-emerald-800",
          water: "4.8 cm",
          soilPh: "6.4",
          chlorophyll: "LCC Cấp 4",
          density: "235 dảnh/m²",
          pestRate: "Thấp",
          note: "Mật độ sạ hơi dày, đang tỉa dặm bổ sung."
        },
        {
          id: "C3",
          name: "Lô C3 - Kề trạm quan trắc IoT",
          area: "1.0 ha",
          healthScore: 95,
          status: "optimal",
          statusText: "Tối ưu",
          badgeColor: "bg-emerald-100 text-emerald-800",
          water: "5.2 cm",
          soilPh: "6.6",
          chlorophyll: "LCC Cấp 4",
          density: "215 dảnh/m²",
          pestRate: "An toàn",
          note: "Cảm biến pH và mực nước kết nối thời gian thực 5 phút/lần."
        }
      ],
      waterHistory: [
        { day: "T2", val: 5.5, status: "Ngập" },
        { day: "T3", val: 5.2, status: "Ngập" },
        { day: "T4", val: 5.0, status: "Ngập" },
        { day: "T5", val: 5.0, status: "Ngập" },
        { day: "T6", val: 4.8, status: "Ngập" },
        { day: "T7", val: 5.0, status: "Ngập" },
        { day: "CN", val: 5.0, status: "Ngập giữ cỏ" }
      ],
      nutrients: {
        n: { label: "Đạm (N)", level: 85, text: "Đạt chuẩn", color: "bg-emerald-500" },
        p: { label: "Lân hữu dụng (P₂O₅)", level: 82, text: "Tốt", color: "bg-emerald-500" },
        k: { label: "Kali trao đổi (K₂O)", level: 78, text: "Khá", color: "bg-emerald-500" },
        zn: { label: "Kẽm vi lượng (Zn)", level: 80, text: "Đạt", color: "bg-emerald-500" },
        si: { label: "Silic hữu hiệu (SiO₂)", level: 75, text: "Đạt", color: "bg-emerald-500" }
      }
    }
  };

  // State
  let currentFieldKey = "A";
  let currentFilter = "all";
  let activeTab = "tabAwd";
  let isAutoGate = true;

  // DOM Elements
  const fieldSelect = document.getElementById("fieldSelect");
  const fieldSummaryVariety = document.getElementById("fieldSummaryVariety");
  const fieldSummaryArea = document.getElementById("fieldSummaryArea");
  const fieldSummaryAge = document.getElementById("fieldSummaryAge");
  const fieldSummaryStage = document.getElementById("fieldSummaryStage");

  // KPI Elements
  const kpiHealthScore = document.getElementById("kpiHealthScore");
  const kpiHealthStatus = document.getElementById("kpiHealthStatus");
  const kpiHealthBar = document.getElementById("kpiHealthBar");

  const kpiWaterLevel = document.getElementById("kpiWaterLevel");
  const kpiWaterStatus = document.getElementById("kpiWaterStatus");
  const kpiWaterBar = document.getElementById("kpiWaterBar");

  const kpiSoilPh = document.getElementById("kpiSoilPh");
  const kpiSoilStatus = document.getElementById("kpiSoilStatus");
  const kpiSoilEc = document.getElementById("kpiSoilEc");

  const kpiPestRisk = document.getElementById("kpiPestRisk");
  const kpiPestStatus = document.getElementById("kpiPestStatus");
  const kpiPestBar = document.getElementById("kpiPestBar");

  // Sector Grid Container
  const sectorGridContainer = document.getElementById("sectorGridContainer");
  const sectorFilterButtons = document.querySelectorAll(".sector-filter-btn");

  // Tabs
  const tabBtnAwd = document.getElementById("tabBtnAwd");
  const tabBtnNutrient = document.getElementById("tabBtnNutrient");
  const tabBtnIpm = document.getElementById("tabBtnIpm");
  const tabContentAwd = document.getElementById("tabContentAwd");
  const tabContentNutrient = document.getElementById("tabContentNutrient");
  const tabContentIpm = document.getElementById("tabContentIpm");

  // Actuator Sluice Gate
  const btnToggleGateMode = document.getElementById("btnToggleGateMode");
  const gateModeStatus = document.getElementById("gateModeStatus");
  const btnManualDrain = document.getElementById("btnManualDrain");
  const btnManualPump = document.getElementById("btnManualPump");

  // Action Buttons
  const btnSyncIot = document.getElementById("btnSyncIot");
  const btnExportReport = document.getElementById("btnExportReport");
  const btnAddLogEntry = document.getElementById("btnAddLogEntry");

  // Toast Notification
  const toastNotification = document.getElementById("toastNotification");
  const toastMessage = document.getElementById("toastMessage");

  // Modals
  const sectorModal = document.getElementById("sectorModal");
  const sectorModalContent = document.getElementById("sectorModalContent");
  const btnCloseSectorModal = document.getElementById("btnCloseSectorModal");

  const logModal = document.getElementById("logModal");
  const btnCloseLogModal = document.getElementById("btnCloseLogModal");
  const formAddLog = document.getElementById("formAddLog");

  // ==========================================
  // 2. HELPER FUNCTIONS
  // ==========================================
  function showToast(msg) {
    if (!toastNotification || !toastMessage) return;
    toastMessage.textContent = msg;
    toastNotification.classList.remove("translate-y-24", "opacity-0");
    toastNotification.classList.add("translate-y-0", "opacity-100");
    setTimeout(() => {
      toastNotification.classList.remove("translate-y-0", "opacity-100");
      toastNotification.classList.add("translate-y-24", "opacity-0");
    }, 3200);
  }

  // ==========================================
  // 3. RENDER FUNCTIONS
  // ==========================================
  function renderField(fieldKey) {
    const data = FIELD_DATA[fieldKey] || FIELD_DATA.A;

    // Header Summary
    if (fieldSummaryVariety) fieldSummaryVariety.textContent = data.variety;
    if (fieldSummaryArea) fieldSummaryArea.textContent = data.area;
    if (fieldSummaryAge) fieldSummaryAge.textContent = `${data.ageDays} ngày tuổi (Sạ: ${data.sowingDate})`;
    if (fieldSummaryStage) fieldSummaryStage.textContent = data.stage;

    // KPI 1: Sức khỏe ruộng
    if (kpiHealthScore) kpiHealthScore.textContent = data.healthIndex;
    if (kpiHealthStatus) kpiHealthStatus.textContent = data.healthStatus;
    if (kpiHealthBar) kpiHealthBar.style.width = `${data.healthIndex}%`;

    // KPI 2: Mực nước AWD
    if (kpiWaterLevel) kpiWaterLevel.textContent = data.waterLevel;
    if (kpiWaterStatus) kpiWaterStatus.textContent = data.waterStatus;
    if (kpiWaterBar) kpiWaterBar.style.width = `${data.waterBarPct}%`;

    // KPI 3: Thổ nhưỡng pH & EC
    if (kpiSoilPh) kpiSoilPh.textContent = `pH ${data.soilPh}`;
    if (kpiSoilStatus) kpiSoilStatus.textContent = data.soilPhStatus;
    if (kpiSoilEc) kpiSoilEc.textContent = `EC: ${data.soilEc} • Ẩm: ${data.soilMoisture}`;

    // KPI 4: Rủi ro sâu bệnh
    if (kpiPestRisk) kpiPestRisk.textContent = data.pestRisk;
    if (kpiPestStatus) kpiPestStatus.textContent = data.pestRiskStatus;
    if (kpiPestBar) {
      const riskNum = parseInt(data.pestRisk, 10) || 15;
      kpiPestBar.style.width = `${Math.min(riskNum * 3, 100)}%`;
      if (riskNum > 20) {
        kpiPestBar.className = "bg-error h-full rounded-full transition-all duration-700";
      } else {
        kpiPestBar.className = "bg-amber-500 h-full rounded-full transition-all duration-700";
      }
    }

    // Render Sector Grid
    renderSectors(data.sectors, currentFilter);

    // Render AWD chart items
    renderAwdChart(data.waterHistory);

    // Render Nutrients
    renderNutrients(data.nutrients);
  }

  function renderSectors(sectors, filter) {
    if (!sectorGridContainer) return;

    let filtered = sectors;
    if (filter === "optimal") {
      filtered = sectors.filter((s) => s.status === "optimal");
    } else if (filter === "attention") {
      filtered = sectors.filter((s) => s.status === "warning" || s.status === "danger");
    }

    if (filtered.length === 0) {
      sectorGridContainer.innerHTML = `
        <div class="col-span-full py-8 text-center text-on-surface-variant font-body-md">
          Không có lô ruộng nào phù hợp với bộ lọc hiện tại.
        </div>
      `;
      return;
    }

    sectorGridContainer.innerHTML = filtered
      .map(
        (sector) => `
        <div class="sector-card bg-surface-container-low/70 border border-outline-variant/40 hover:border-primary/50 rounded-2xl p-space-md flex flex-col justify-between cursor-pointer group" data-sector-id="${sector.id}">
          <div>
            <div class="flex items-start justify-between gap-2 mb-3">
              <div>
                <div class="flex items-center gap-2">
                  <span class="font-headline-sm text-headline-sm text-on-surface font-bold">${sector.id}</span>
                  <span class="font-label-sm text-label-sm px-2.5 py-0.5 rounded-full ${sector.badgeColor} font-semibold">
                    ${sector.statusText}
                  </span>
                </div>
                <h4 class="font-body-sm text-body-sm text-on-surface-variant font-medium mt-0.5">${sector.name}</h4>
              </div>
              <div class="text-right">
                <span class="font-numeric-metric text-[22px] font-bold ${sector.healthScore >= 90 ? "text-primary" : sector.healthScore >= 80 ? "text-amber-700" : "text-error"}">
                  ${sector.healthScore}
                </span>
                <span class="font-label-sm text-label-sm text-on-surface-variant block">Điểm sinh thái</span>
              </div>
            </div>

            <!-- Mini Telemetry Strip -->
            <div class="grid grid-cols-3 gap-2 py-2 border-y border-outline-variant/30 text-[11px] font-telemetry-code mb-3 bg-surface-container-lowest/60 rounded-xl px-2">
              <div class="text-center">
                <span class="text-on-surface-variant block">Mực nước</span>
                <span class="font-bold text-on-surface">${sector.water}</span>
              </div>
              <div class="text-center border-x border-outline-variant/30">
                <span class="text-on-surface-variant block">pH Đất</span>
                <span class="font-bold text-on-surface">${sector.soilPh}</span>
              </div>
              <div class="text-center">
                <span class="text-on-surface-variant block">Màu lá</span>
                <span class="font-bold text-secondary">${sector.chlorophyll.split(" ")[0]}</span>
              </div>
            </div>

            <!-- Notes -->
            <p class="font-body-sm text-body-sm text-on-surface-variant line-clamp-2 mb-3">
              ${sector.note}
            </p>
          </div>

          <div class="flex items-center justify-between pt-2 border-t border-outline-variant/30 text-label-sm font-label-sm text-primary group-hover:text-primary-container">
            <span class="flex items-center gap-1">
              <span class="material-symbols-outlined text-[16px]">visibility</span>
              Xem chi tiết lô ${sector.id}
            </span>
            <span class="material-symbols-outlined text-[16px] transition-transform group-hover:translate-x-1">chevron_right</span>
          </div>
        </div>
      `
      )
      .join("");

    // Attach click listeners to cards
    sectorGridContainer.querySelectorAll(".sector-card").forEach((card) => {
      card.addEventListener("click", () => {
        const secId = card.getAttribute("data-sector-id");
        openSectorModal(secId);
      });
    });
  }

  function renderAwdChart(history) {
    const chartContainer = document.getElementById("awdChartBars");
    if (!chartContainer || !history) return;

    chartContainer.innerHTML = history
      .map((item) => {
        // Range 0 -> 10 cm, scale to % of 160px height
        const heightPct = Math.min(Math.max((item.val / 10) * 100, 10), 100);
        const isOptimum = item.val >= 3.0 && item.val <= 5.5;
        const barColor = isOptimum ? "bg-secondary" : item.val < 3.0 ? "bg-amber-500" : "bg-sky-600";

        return `
        <div class="flex-1 flex flex-col items-center justify-end h-40 group relative">
          <!-- Tooltip on hover -->
          <div class="absolute -top-10 opacity-0 group-hover:opacity-100 transition-opacity bg-inverse-surface text-inverse-on-surface text-[10px] py-1 px-2 rounded font-telemetry-code whitespace-nowrap pointer-events-none z-10 shadow">
            ${item.val} cm - ${item.status}
          </div>
          <div class="w-full max-w-[32px] ${barColor} rounded-t-lg transition-all duration-500 hover:brightness-110 shadow-sm" style="height: ${heightPct}%;"></div>
          <span class="font-telemetry-code text-[11px] text-on-surface-variant mt-2">${item.day}</span>
        </div>
      `;
      })
      .join("");
  }

  function renderNutrients(nutrients) {
    const nutrientList = document.getElementById("nutrientBarsContainer");
    if (!nutrientList || !nutrients) return;

    nutrientList.innerHTML = Object.keys(nutrients)
      .map((key) => {
        const n = nutrients[key];
        return `
        <div class="space-y-1.5 p-3 rounded-xl bg-surface-container-low/70">
          <div class="flex items-center justify-between text-body-sm font-body-sm">
            <span class="font-semibold text-on-surface">${n.label}</span>
            <span class="font-telemetry-code font-bold ${n.level >= 75 ? "text-primary" : "text-amber-700"}">${n.text} (${n.level}%)</span>
          </div>
          <div class="w-full bg-surface-container-high h-2 rounded-full overflow-hidden">
            <div class="${n.color} h-full rounded-full transition-all duration-700" style="width: ${n.level}%;"></div>
          </div>
        </div>
      `;
      })
      .join("");
  }

  // ==========================================
  // 4. MODAL INTERACTIONS
  // ==========================================
  function openSectorModal(sectorId) {
    const field = FIELD_DATA[currentFieldKey];
    if (!field) return;
    const sector = field.sectors.find((s) => s.id === sectorId);
    if (!sector || !sectorModal || !sectorModalContent) return;

    sectorModalContent.innerHTML = `
      <div class="space-y-space-md">
        <!-- Header -->
        <div class="flex items-start justify-between pb-3 border-b border-outline-variant/30">
          <div>
            <div class="flex items-center gap-2">
              <h3 class="font-headline-md text-headline-md text-primary font-bold">${sector.name}</h3>
              <span class="font-label-sm text-label-sm px-2.5 py-0.5 rounded-full ${sector.badgeColor} font-semibold">
                ${sector.statusText}
              </span>
            </div>
            <p class="font-body-sm text-body-sm text-on-surface-variant mt-1">
              Thuộc ${field.name} • Diện tích phân lô: <strong>${sector.area}</strong>
            </p>
          </div>
          <div class="text-right">
            <span class="font-numeric-metric text-numeric-metric font-bold text-primary">${sector.healthScore}</span>
            <span class="font-label-sm text-label-sm text-on-surface-variant block">/ 100 điểm</span>
          </div>
        </div>

        <!-- Telemetry Matrix -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div class="p-3 rounded-xl bg-surface-container-low">
            <span class="font-label-sm text-label-sm text-on-surface-variant block">Mực nước mặt ruộng</span>
            <span class="font-telemetry-code text-[18px] font-bold text-sky-700">${sector.water}</span>
          </div>
          <div class="p-3 rounded-xl bg-surface-container-low">
            <span class="font-label-sm text-label-sm text-on-surface-variant block">Độ pH tầng đất rễ</span>
            <span class="font-telemetry-code text-[18px] font-bold text-primary">${sector.soilPh}</span>
          </div>
          <div class="p-3 rounded-xl bg-surface-container-low">
            <span class="font-label-sm text-label-sm text-on-surface-variant block">Chỉ số màu lá LCC</span>
            <span class="font-telemetry-code text-[16px] font-bold text-secondary">${sector.chlorophyll}</span>
          </div>
          <div class="p-3 rounded-xl bg-surface-container-low">
            <span class="font-label-sm text-label-sm text-on-surface-variant block">Mật độ chồi dảnh</span>
            <span class="font-telemetry-code text-[16px] font-bold text-on-surface">${sector.density}</span>
          </div>
        </div>

        <!-- Agronomic Assessment Box -->
        <div class="p-space-md rounded-2xl bg-secondary-fixed/20 border border-secondary/20 space-y-2">
          <div class="flex items-center gap-2">
            <span class="material-symbols-outlined text-secondary text-[20px]">psychology</span>
            <h4 class="font-label-lg text-label-lg font-bold text-secondary">Đánh giá Nông học & AI Thực địa</h4>
          </div>
          <p class="font-body-md text-body-md text-on-surface">
            ${sector.note}
          </p>
          <div class="pt-2 text-body-sm text-on-surface-variant">
            <strong>Tình trạng sâu hại:</strong> ${sector.pestRate}
          </div>
        </div>

        <!-- Quick Field Actions inside Modal -->
        <div class="pt-2 flex flex-wrap gap-2 justify-end">
          <a href="../KiemTraCayAI/KiemTraCayAI.html" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-surface-container-high hover:bg-surface-container-highest text-on-surface font-label-md text-label-md transition-colors">
            <span class="material-symbols-outlined text-[18px]">photo_camera</span>
            <span>Chụp ảnh quét AI cho lô ${sector.id}</span>
          </a>
          <button type="button" class="btn-irrigate-sector inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-colors" data-sector="${sector.id}">
            <span class="material-symbols-outlined text-[18px]">water_drop</span>
            <span>Điều tiết van nước lô này</span>
          </button>
        </div>
      </div>
    `;

    // Bind irrigate button
    const btnIrrigate = sectorModalContent.querySelector(".btn-irrigate-sector");
    if (btnIrrigate) {
      btnIrrigate.addEventListener("click", () => {
        showToast(`Đã gửi lệnh vi điều tiết van tưới khu vực Lô ${sector.id}.`);
        closeSectorModalFunc();
      });
    }

    sectorModal.classList.remove("hidden");
  }

  function closeSectorModalFunc() {
    if (sectorModal) sectorModal.classList.add("hidden");
  }

  // ==========================================
  // 5. EVENT LISTENERS
  // ==========================================
  // Select Field change
  if (fieldSelect) {
    fieldSelect.addEventListener("change", (e) => {
      currentFieldKey = e.target.value;
      renderField(currentFieldKey);
      showToast(`Đã chuyển đổi sang ${FIELD_DATA[currentFieldKey]?.name}`);
    });
  }

  // Filter Sectors
  sectorFilterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      sectorFilterButtons.forEach((b) => {
        b.classList.remove("bg-primary", "text-on-primary", "shadow-sm");
        b.classList.add("bg-surface-container-low", "text-on-surface-variant");
      });
      btn.classList.add("bg-primary", "text-on-primary", "shadow-sm");
      btn.classList.remove("bg-surface-container-low", "text-on-surface-variant");

      currentFilter = btn.getAttribute("data-filter") || "all";
      renderSectors(FIELD_DATA[currentFieldKey].sectors, currentFilter);
    });
  });

  // Tab switching
  function switchTab(tabId) {
    activeTab = tabId;
    [tabBtnAwd, tabBtnNutrient, tabBtnIpm].forEach((b) => {
      if (b) {
        b.classList.remove("text-primary", "border-primary", "font-bold");
        b.classList.add("text-on-surface-variant", "border-transparent");
      }
    });

    [tabContentAwd, tabContentNutrient, tabContentIpm].forEach((c) => {
      if (c) c.classList.add("hidden");
    });

    if (tabId === "tabAwd") {
      tabBtnAwd?.classList.add("text-primary", "border-primary", "font-bold");
      tabBtnAwd?.classList.remove("text-on-surface-variant", "border-transparent");
      tabContentAwd?.classList.remove("hidden");
    } else if (tabId === "tabNutrient") {
      tabBtnNutrient?.classList.add("text-primary", "border-primary", "font-bold");
      tabBtnNutrient?.classList.remove("text-on-surface-variant", "border-transparent");
      tabContentNutrient?.classList.remove("hidden");
    } else if (tabId === "tabIpm") {
      tabBtnIpm?.classList.add("text-primary", "border-primary", "font-bold");
      tabBtnIpm?.classList.remove("text-on-surface-variant", "border-transparent");
      tabContentIpm?.classList.remove("hidden");
    }
  }

  if (tabBtnAwd) tabBtnAwd.addEventListener("click", () => switchTab("tabAwd"));
  if (tabBtnNutrient) tabBtnNutrient.addEventListener("click", () => switchTab("tabNutrient"));
  if (tabBtnIpm) tabBtnIpm.addEventListener("click", () => switchTab("tabIpm"));

  // Toggle Sluice Gate Mode
  if (btnToggleGateMode) {
    btnToggleGateMode.addEventListener("click", () => {
      isAutoGate = !isAutoGate;
      if (isAutoGate) {
        btnToggleGateMode.textContent = "Chế độ: Tự động (AWD)";
        btnToggleGateMode.className = "px-3 py-1.5 rounded-xl bg-secondary text-on-secondary font-label-sm text-label-sm shadow-sm transition-all";
        if (gateModeStatus) gateModeStatus.textContent = "AI tự động đóng/mở van theo chu kỳ tưới AWD";
        showToast("Đã kích hoạt chế độ điều tiết van cống TỰ ĐỘNG AI.");
      } else {
        btnToggleGateMode.textContent = "Chế độ: Thủ công";
        btnToggleGateMode.className = "px-3 py-1.5 rounded-xl bg-surface-container-high text-on-surface font-label-sm text-label-sm shadow-sm transition-all";
        if (gateModeStatus) gateModeStatus.textContent = "Chế độ điều khiển thủ công bởi kỹ sư vận hành";
        showToast("Đã chuyển sang chế độ điều tiết cống THỦ CÔNG.");
      }
    });
  }

  if (btnManualDrain) {
    btnManualDrain.addEventListener("click", () => {
      showToast("Đã mở van xả đáy cống Kênh Đông (Xả nước -1.5cm/h).");
    });
  }

  if (btnManualPump) {
    btnManualPump.addEventListener("click", () => {
      showToast("Đã kích hoạt trạm bơm bổ sung nước (+2.0cm/h).");
    });
  }

  // IoT Sync Action
  if (btnSyncIot) {
    btnSyncIot.addEventListener("click", () => {
      const icon = btnSyncIot.querySelector(".material-symbols-outlined");
      if (icon) icon.classList.add("animate-spin");
      setTimeout(() => {
        if (icon) icon.classList.remove("animate-spin");
        renderField(currentFieldKey);
        showToast("Đã đồng bộ thành công dữ liệu từ 14 trạm cảm biến IoT thực địa!");
      }, 900);
    });
  }

  // Export PDF Report
  if (btnExportReport) {
    btnExportReport.addEventListener("click", () => {
      showToast(`Đã kết xuất Phiếu Báo Cáo Nông Học ${FIELD_DATA[currentFieldKey]?.name} (PDF).`);
    });
  }

  // Add Log Entry Modal
  if (btnAddLogEntry && logModal) {
    btnAddLogEntry.addEventListener("click", () => {
      logModal.classList.remove("hidden");
    });
  }

  if (btnCloseLogModal && logModal) {
    btnCloseLogModal.addEventListener("click", () => {
      logModal.classList.add("hidden");
    });
  }

  if (formAddLog) {
    formAddLog.addEventListener("submit", (e) => {
      e.preventDefault();
      const content = document.getElementById("logContentInput")?.value || "";
      if (content.trim()) {
        showToast("Đã lưu ghi chép nhật ký nông học vào hệ thống.");
        formAddLog.reset();
        logModal?.classList.add("hidden");
      }
    });
  }

  // Close Sector Modal Button & Backdrop
  if (btnCloseSectorModal) {
    btnCloseSectorModal.addEventListener("click", closeSectorModalFunc);
  }
  if (sectorModal) {
    sectorModal.addEventListener("click", (e) => {
      if (e.target === sectorModal) closeSectorModalFunc();
    });
  }

  // INITIAL RUN
  renderField(currentFieldKey);
});
